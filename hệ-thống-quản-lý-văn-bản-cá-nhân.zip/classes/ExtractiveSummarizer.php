<?php
/**
 * Lớp Tóm Tắt Văn Bản Extractive Automaton (Thuật toán TF-IDF / Tần suất Từ)
 * Tự động trích xuất 3-5 câu quan trọng nhất mà KHÔNG DÙNG AI API bên ngoài
 */

class ExtractiveSummarizer {
    // Danh sách Stop Words Tiếng Việt cơ bản
    private static array $stopWords = [
        'và', 'của', 'là', 'có', 'cho', 'với', 'như', 'đã', 'đang', 'được', 'trong', 'để', 'vào', 'này',
        'khi', 'tại', 'theo', 'về', 'những', 'các', 'một', 'người', 'ra', 'sự', 'việc', 'đó', 'từ', 'trên',
        'cơ', 'quan', 'bộ', 'ban', 'ngành', 'ủy', 'phường', 'xã', 'thành', 'phố', 'tỉnh', 'số', 'ngày', 'tháng', 'năm'
    ];

    /**
     * Tự động trích xuất tóm tắt từ văn bản thô
     */
    public static function summarize(string $text, int $maxSentences = 3): string {
        $text = trim($text);
        if (mb_strlen($text) < 50) {
            return "Nội dung ngắn hoặc file định dạng quét ảnh - Vui lòng xem tài liệu gốc bên dưới.";
        }

        // 1. Tách văn bản thành danh sách câu
        $rawSentences = preg_split('/(?<=[.!?])\s+|\n+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        $sentences = [];
        foreach ($rawSentences as $s) {
            $cleaned = trim($s);
            if (mb_strlen($cleaned) > 15) {
                $sentences[] = $cleaned;
            }
        }

        if (count($sentences) <= $maxSentences) {
            return implode(' ', $sentences);
        }

        // 2. Tính tần suất từ (Term Frequency)
        $wordFreq = [];
        foreach ($sentences as $sentence) {
            $words = self::tokenize($sentence);
            foreach ($words as $word) {
                if (!in_array($word, self::$stopWords) && mb_strlen($word) > 1) {
                    $wordFreq[$word] = ($wordFreq[$word] ?? 0) + 1;
                }
            }
        }

        if (empty($wordFreq)) {
            return implode(' ', array_slice($sentences, 0, $maxSentences));
        }

        // 3. Tính điểm cho mỗi câu dựa trên trọng số các từ chứa trong câu
        $scores = [];
        foreach ($sentences as $index => $sentence) {
            $words = self::tokenize($sentence);
            $score = 0;
            $countedWords = 0;

            foreach ($words as $word) {
                if (isset($wordFreq[$word])) {
                    $score += $wordFreq[$word];
                    $countedWords++;
                }
            }

            // Chuẩn hóa điểm theo độ dài câu để tránh ưu tiên câu quá dài
            if ($countedWords > 0) {
                $score = $score / sqrt($countedWords);
            }

            // Thêm chút trọng số cho những câu đầu văn bản (vị trí ban hành/tiêu đề)
            if ($index === 0) $score *= 1.3;
            if ($index === 1) $score *= 1.1;

            $scores[$index] = $score;
        }

        // 4. Chọn top $maxSentences câu có điểm cao nhất
        arsort($scores);
        $topIndices = array_slice(array_keys($scores), 0, $maxSentences);
        sort($topIndices); // Sắp xếp lại theo thứ tự ban đầu trong văn bản

        $selectedSentences = [];
        foreach ($topIndices as $idx) {
            $selectedSentences[] = $sentences[$idx];
        }

        return implode(' ', $selectedSentences);
    }

    /**
     * Tách từ đơn giản cho tiếng Việt
     */
    private static function tokenize(string $sentence): array {
        $clean = mb_strtolower($sentence, 'UTF-8');
        $clean = preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $clean);
        return array_values(array_filter(explode(' ', $clean)));
    }
}
