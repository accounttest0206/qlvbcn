import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));

// Serving static uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}
app.use("/uploads", express.static(uploadDir));

// Initial In-Memory State matching database.sql
let categories = [
  { id: 1, name: "Quyết định / Chỉ thị", description: "Các quyết định hành chính, chỉ thị điều hành công việc" },
  { id: 2, name: "Thông báo / Công văn", description: "Công văn đi, công văn đến, thông báo nội bộ" },
  { id: 3, name: "Kế hoạch / Báo cáo", description: "Báo cáo định kỳ, kế hoạch công tác quý/năm" },
  { id: 4, name: "Hợp đồng / Biên bản", description: "Hợp đồng kinh tế, biên bản cuộc họp và thỏa thuận" }
];

let documents = [
  {
    id: 1,
    user_id: 1,
    category_id: 1,
    category_name: "Quyết định / Chỉ thị",
    title: "Quyết định ban hành Quy chế Làm việc mới năm 2026",
    doc_number: "124/QĐ-UBND",
    summary: "Quyết định áp dụng quy chế làm việc kết hợp làm việc từ xa và tại văn phòng cho toàn bộ nhân sự.",
    auto_summary: "Căn cứ Luật Quản lý Hành chính. Ban hành quy chế làm việc mới áp dụng từ tháng 8 năm 2026. Tất cả các đơn vị có trách nhiệm thi hành nghiêm túc quy chế này.",
    doc_type: "luu",
    status: "hoan_thanh",
    progress: 100,
    file_path: "uploads/sample_qd.pdf",
    file_type: "pdf",
    file_size: 1048576,
    issued_date: "2026-08-01",
    due_date: "2026-08-05",
    created_at: "2026-08-01 08:30:00",
    author_name: "Quản Trị Viên (Admin)"
  },
  {
    id: 2,
    user_id: 2,
    category_id: 3,
    category_name: "Kế hoạch / Báo cáo",
    title: "Kế hoạch Triển khai Nâng cấp Hệ thống CNTT Quý 3/2026",
    doc_number: "45/KH-CNTT",
    summary: "Chi tiết kế hoạch bảo trì máy chủ, nâng cấp hạ tầng mạng và kiểm tra an toàn thông tin.",
    auto_summary: "Kế hoạch nâng cấp hệ thống máy chủ cơ sở dữ liệu và hạ tầng mạng LAN. Thời gian thực hiện từ ngày 15/08 đến 30/08/2026. Phân công đội ngũ an ninh mạng chịu trách nhiệm túc trực 24/7.",
    doc_type: "thuc_hien",
    status: "dang_thuc_hien",
    progress: 65,
    file_path: "uploads/sample_kh.docx",
    file_type: "docx",
    file_size: 2097152,
    issued_date: "2026-08-02",
    due_date: "2026-08-25",
    created_at: "2026-08-02 09:15:00",
    author_name: "Nguyễn Văn A"
  },
  {
    id: 3,
    user_id: 2,
    category_id: 2,
    category_name: "Thông báo / Công văn",
    title: "Công văn v/v Chuẩn bị Báo cáo Kiểm toán Tài chính",
    doc_number: "89/CV-KT",
    summary: "Yêu cầu các phòng ban rà soát chứng từ, lập báo cáo thu chi trình Ban Giám đốc.",
    auto_summary: "Công văn yêu cầu hoàn thiện toàn bộ hồ sơ sổ sách kế toán trước ngày 20/08/2026. Các phòng ban phối hợp chặt chẽ với bộ phận Tài chính Kế toán.",
    doc_type: "thuc_hien",
    status: "chua_xu_ly",
    progress: 0,
    file_path: "uploads/sample_cv.pdf",
    file_type: "pdf",
    file_size: 524288,
    issued_date: "2026-08-05",
    due_date: "2026-08-20",
    created_at: "2026-08-05 14:00:00",
    author_name: "Nguyễn Văn A"
  },
  {
    id: 4,
    user_id: 3,
    category_id: 4,
    category_name: "Hợp đồng / Biên bản",
    title: "Biên bản Nghiệm thu Hợp đồng Cung cấp Thiết bị Văn phòng",
    doc_number: "12/BB-NT",
    summary: "Biên bản kiểm tra số lượng và chất lượng máy in, máy chiếu mới bàn giao.",
    auto_summary: "Đã tiến hành nghiệm thu 15 máy in đa năng và 5 máy chiếu HD. Thiết bị hoạt động ổn định và đáp ứng đầy đủ thông số kỹ thuật theo hợp đồng.",
    doc_type: "luu",
    status: "hoan_thanh",
    progress: 100,
    file_path: "uploads/sample_bb.pdf",
    file_type: "pdf",
    file_size: 838860,
    issued_date: "2026-08-06",
    due_date: null,
    created_at: "2026-08-06 11:20:00",
    author_name: "Trần Thị B"
  },
  {
    id: 5,
    user_id: 2,
    category_id: 3,
    category_name: "Kế hoạch / Báo cáo",
    title: "Báo cáo Đánh giá Tiến độ Dự án Quản lý Văn bản Cá nhân",
    doc_number: "102/BC-QLVB",
    summary: "Báo cáo tình hình thiết kế cơ sở dữ liệu, xây dựng module Tóm tắt TF-IDF và xem file trực tuyến.",
    auto_summary: "Hệ thống đã hoàn thiện 80% tính năng chính bao gồm phân quyền, thống kê Chart.js và trích xuất tóm tắt văn bản. Dự kiến hoàn thành nghiệm thu đúng hạn.",
    doc_type: "thuc_hien",
    status: "dang_thuc_hien",
    progress: 80,
    file_path: "uploads/sample_bc.docx",
    file_type: "docx",
    file_size: 1572864,
    issued_date: "2026-08-08",
    due_date: "2026-08-18",
    created_at: "2026-08-08 16:45:00",
    author_name: "Nguyễn Văn A"
  }
];

let progressLogs = [
  { id: 1, document_id: 2, user_id: 2, user_name: "Nguyễn Văn A", old_progress: 0, new_progress: 30, old_status: "chua_xu_ly", new_status: "dang_thuc_hien", note: "Khởi tạo kế hoạch và phân công nhân sự khảo sát hạ tầng", created_at: "2026-08-03 10:00:00" },
  { id: 2, document_id: 2, user_id: 2, user_name: "Nguyễn Văn A", old_progress: 30, new_progress: 65, old_status: "dang_thuc_hien", new_status: "dang_thuc_hien", note: "Hoàn thành việc cấu hình máy chủ ảo hóa và sao lưu dữ liệu cũ", created_at: "2026-08-07 15:30:00" },
  { id: 3, document_id: 5, user_id: 2, user_name: "Nguyễn Văn A", old_progress: 0, new_progress: 50, old_status: "chua_xu_ly", new_status: "dang_thuc_hien", note: "Hoàn thành thiết kế giao diện Bootstrap 5.3 Dark/Light mode", created_at: "2026-08-09 09:00:00" },
  { id: 4, document_id: 5, user_id: 2, user_name: "Nguyễn Văn A", old_progress: 50, new_progress: 80, old_status: "dang_thuc_hien", new_status: "dang_thuc_hien", note: "Tích hợp Mammoth.js xem file Word và viết thuật toán Extractive TF-IDF", created_at: "2026-08-10 08:00:00" }
];

// Extractive TF-IDF Summarizer Algorithm in Node.js
function summarizeExtractive(text: string, maxSentences: number = 3): string {
  const trimmed = text.trim();
  if (trimmed.length < 40) {
    return "Nội dung ngắn hoặc file dạng quét ảnh - Vui lòng tham khảo tệp văn bản gốc.";
  }

  const rawSentences = trimmed.split(/(?<=[.!?])\s+|\n+/).map(s => s.trim()).filter(s => s.length > 15);
  if (rawSentences.length <= maxSentences) {
    return rawSentences.join(" ");
  }

  const stopWords = new Set(["và", "của", "là", "có", "cho", "với", "như", "đã", "đang", "được", "trong", "để", "vào", "này", "khi", "tại", "theo", "về", "những", "các", "một", "người", "ra", "sự", "việc", "đó", "từ", "trên"]);
  const wordFreq: Record<string, number> = {};

  rawSentences.forEach(s => {
    const words = s.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, "").split(/\s+/);
    words.forEach(w => {
      if (w.length > 1 && !stopWords.has(w)) {
        wordFreq[w] = (wordFreq[w] || 0) + 1;
      }
    });
  });

  const scores = rawSentences.map((s, idx) => {
    const words = s.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, "").split(/\s+/);
    let score = 0;
    let count = 0;
    words.forEach(w => {
      if (wordFreq[w]) {
        score += wordFreq[w];
        count++;
      }
    });
    let normalized = count > 0 ? score / Math.sqrt(count) : 0;
    if (idx === 0) normalized *= 1.3;
    if (idx === 1) normalized *= 1.1;
    return { idx, score: normalized, sentence: s };
  });

  scores.sort((a, b) => b.score - a.score);
  const selected = scores.slice(0, maxSentences).sort((a, b) => a.idx - b.idx);
  return selected.map(item => item.sentence).join(" ");
}

// REST API Endpoints
app.get("/api/categories", (req, res) => {
  res.json(categories);
});

app.get("/api/documents", (req, res) => {
  let result = [...documents];
  const { keyword, doc_type, status, category_id, user_role, user_id } = req.query;

  if (user_role !== "Admin" && user_id) {
    result = result.filter(d => d.user_id === Number(user_id));
  }

  if (keyword) {
    const kw = String(keyword).toLowerCase();
    result = result.filter(d => 
      d.title.toLowerCase().includes(kw) || 
      d.doc_number.toLowerCase().includes(kw) || 
      d.summary.toLowerCase().includes(kw)
    );
  }

  if (doc_type) {
    result = result.filter(d => d.doc_type === doc_type);
  }

  if (status) {
    result = result.filter(d => d.status === status);
  }

  if (category_id) {
    result = result.filter(d => d.category_id === Number(category_id));
  }

  res.json(result);
});

app.get("/api/documents/:id", (req, res) => {
  const id = Number(req.params.id);
  const doc = documents.find(d => d.id === id);
  if (!doc) {
    return res.status(404).json({ error: "Không tìm thấy văn bản" });
  }
  const logs = progressLogs.filter(l => l.document_id === id).sort((a,b) => b.id - a.id);
  res.json({ document: doc, logs });
});

app.post("/api/documents", (req, res) => {
  const { title, doc_number, category_id, doc_type, summary, issued_date, due_date, status, progress, user_id, author_name, file_path, file_type, file_size } = req.body;
  
  const cat = categories.find(c => c.id === Number(category_id));
  const auto_summary = summarizeExtractive(summary, 3);

  const newDoc = {
    id: documents.length > 0 ? Math.max(...documents.map(d => d.id)) + 1 : 1,
    user_id: user_id || 1,
    category_id: category_id ? Number(category_id) : null,
    category_name: cat ? cat.name : "Chưa phân loại",
    title,
    doc_number,
    summary,
    auto_summary,
    doc_type: doc_type || "luu",
    status: status || "chua_xu_ly",
    progress: Number(progress) || 0,
    file_path: file_path || null,
    file_type: file_type || null,
    file_size: file_size || 0,
    issued_date: issued_date || null,
    due_date: due_date || null,
    created_at: new Date().toISOString().replace('T', ' ').substring(0, 19),
    author_name: author_name || "Quản Trị Viên"
  };

  documents.unshift(newDoc);
  res.json(newDoc);
});

app.put("/api/documents/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = documents.findIndex(d => d.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Không tìm thấy văn bản" });
  }

  const { title, doc_number, category_id, doc_type, summary, issued_date, due_date } = req.body;
  const cat = categories.find(c => c.id === Number(category_id));

  documents[index] = {
    ...documents[index],
    title: title || documents[index].title,
    doc_number: doc_number || documents[index].doc_number,
    category_id: category_id ? Number(category_id) : documents[index].category_id,
    category_name: cat ? cat.name : documents[index].category_name,
    doc_type: doc_type || documents[index].doc_type,
    summary: summary !== undefined ? summary : documents[index].summary,
    auto_summary: summarizeExtractive(summary || documents[index].summary, 3),
    issued_date: issued_date || documents[index].issued_date,
    due_date: due_date || documents[index].due_date
  };

  res.json(documents[index]);
});

app.delete("/api/documents/:id", (req, res) => {
  const id = Number(req.params.id);
  documents = documents.filter(d => d.id !== id);
  res.json({ success: true });
});

app.post("/api/documents/:id/progress", (req, res) => {
  const id = Number(req.params.id);
  const doc = documents.find(d => d.id === id);
  if (!doc) return res.status(404).json({ error: "Văn bản không tồn tại" });

  let { new_progress, new_status, note, user_id, user_name } = req.body;
  new_progress = Number(new_progress);

  if (new_progress >= 100) {
    new_progress = 100;
    new_status = "hoan_thanh";
  } else if (new_progress > 0 && new_status === "chua_xu_ly") {
    new_status = "dang_thuc_hien";
  }

  const old_progress = doc.progress;
  const old_status = doc.status;

  doc.progress = new_progress;
  doc.status = new_status;

  const logEntry = {
    id: progressLogs.length + 1,
    document_id: id,
    user_id: user_id || 1,
    user_name: user_name || "Quản Trị Viên",
    old_progress,
    new_progress,
    old_status,
    new_status,
    note: note || "Cập nhật tiến độ",
    created_at: new Date().toISOString().replace('T', ' ').substring(0, 19)
  };

  progressLogs.unshift(logEntry);
  res.json({ document: doc, log: logEntry });
});

app.get("/api/stats", (req, res) => {
  const total = documents.length;
  const luu = documents.filter(d => d.doc_type === "luu").length;
  const thuc_hien = documents.filter(d => d.doc_type === "thuc_hien").length;
  const hoan_thanh = documents.filter(d => d.status === "hoan_thanh").length;
  const dang_thuc_hien = documents.filter(d => d.status === "dang_thuc_hien").length;
  const chua_xu_ly = documents.filter(d => d.status === "chua_xu_ly").length;

  const upcoming_docs = documents
    .filter(d => d.status !== "hoan_thanh" && d.due_date)
    .sort((a,b) => (a.due_date! > b.due_date! ? 1 : -1))
    .slice(0, 5);

  const catStats = categories.map(c => ({
    name: c.name,
    count: documents.filter(d => d.category_id === c.id).length
  }));

  res.json({
    total, luu, thuc_hien, hoan_thanh, dang_thuc_hien, chua_xu_ly,
    recent_docs: documents.slice(0, 5),
    upcoming_docs,
    cat_stats: catStats
  });
});

// Endpoint to view all PHP source code files & database.sql
app.get("/api/php-files", (req, res) => {
  const filesToRead = [
    "database.sql",
    "config/database.php",
    "config/app.php",
    "classes/Database.php",
    "classes/Auth.php",
    "classes/Document.php",
    "classes/ExtractiveSummarizer.php",
    "helpers/file_helper.php",
    "index.php",
    "documents.php",
    "document_detail.php",
    "document_add.php",
    "document_edit.php",
    "document_delete.php",
    "login.php",
    "logout.php",
    "views/header.php",
    "views/footer.php",
    "assets/js/theme.js",
    "assets/js/viewer.js"
  ];

  const fileContents: Record<string, string> = {};

  filesToRead.forEach(filePath => {
    const fullPath = path.join(process.cwd(), filePath);
    if (fs.existsSync(fullPath)) {
      fileContents[filePath] = fs.readFileSync(fullPath, "utf8");
    }
  });

  res.json(fileContents);
});

// Vite Integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
