<?php
/**
 * File Upload Helper & Text Extractor
 */

require_once __DIR__ . '/../config/app.php';

class FileHelper {
    public static function uploadFile(array $file): array {
        if (!isset($file['error']) || is_array($file['error'])) {
            return ['success' => false, 'message' => 'Lỗi dữ liệu tải lên!'];
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'Lỗi khi tải tệp lên server!'];
        }

        if ($file['size'] > MAX_FILE_SIZE) {
            return ['success' => false, 'message' => 'Tệp vượt quá dung lượng tối đa (10MB)!'];
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ALLOWED_EXTENSIONS)) {
            return ['success' => false, 'message' => 'Chỉ chấp nhận các tệp định dạng .pdf, .doc, .docx!'];
        }

        if (!is_dir(UPLOAD_DIR)) {
            mkdir(UPLOAD_DIR, 0777, true);
        }

        $newFileName = time() . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $file['name']);
        $targetPath = UPLOAD_DIR . $newFileName;
        $relativePath = 'uploads/' . $newFileName;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            return [
                'success' => true,
                'path' => $relativePath,
                'full_path' => $targetPath,
                'file_type' => $ext,
                'file_size' => $file['size'],
                'extracted_text' => self::extractText($targetPath, $ext)
            ];
        }

        return ['success' => false, 'message' => 'Không thể lưu tệp vào thư mục đích!'];
    }

    /**
     * Trích xuất văn bản từ file docx/pdf nếu có
     */
    public static function extractText(string $filePath, string $ext): string {
        if ($ext === 'docx') {
            return self::readDocx($filePath);
        }
        return '';
    }

    private static function readDocx(string $filePath): string {
        if (!file_exists($filePath)) return '';
        $zip = new ZipArchive();
        if ($zip->open($filePath) === TRUE) {
            if (($index = $zip->locateName('word/document.xml')) !== false) {
                $data = $zip->getFromIndex($index);
                $zip->close();
                return strip_tags(str_replace('</w:p>', "\n", $data));
            }
            $zip->close();
        }
        return '';
    }
}
