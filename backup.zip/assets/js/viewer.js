/**
 * Inline File Previewer (PDF & DOCX Mammoth.js)
 * Render file trực tiếp trên trình duyệt
 */

function previewDocument(filePath, fileType, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = '<div class="text-center p-4"><div class="spinner-border text-primary" role="status"></div><p class="mt-2 text-muted">Đang tải và xử lý file...</p></div>';

    if (fileType === 'pdf') {
        container.innerHTML = `
            <iframe src="${filePath}" style="width: 100%; height: 650px; border: none; border-radius: 8px;"></iframe>
        `;
    } else if (fileType === 'docx') {
        fetch(filePath)
            .then(response => {
                if (!response.ok) throw new Error("Không thể đọc tệp Word");
                return response.arrayBuffer();
            })
            .then(arrayBuffer => {
                if (typeof mammoth === 'undefined') {
                    throw new Error("Thư viện Mammoth.js chưa được nạp");
                }
                return mammoth.convertToHtml({ arrayBuffer: arrayBuffer });
            })
            .then(result => {
                container.innerHTML = `
                    <div class="p-4 bg-body rounded shadow-sm border docx-content-preview" style="max-height: 650px; overflow-y: auto;">
                        ${result.value}
                    </div>
                `;
            })
            .catch(error => {
                container.innerHTML = `
                    <div class="alert alert-warning m-3">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        Không thể chuyển đổi trực tiếp file .docx: ${error.message}. 
                        <a href="${filePath}" download class="btn btn-sm btn-outline-primary ms-2"><i class="bi bi-download"></i> Tải về file gốc</a>
                    </div>
                `;
            });
    } else {
        container.innerHTML = `
            <div class="alert alert-info m-3 text-center">
                <i class="bi bi-file-earmark-text me-2 fs-4"></i>
                Định dạng tệp .${fileType} không hỗ trợ xem nhanh inline. 
                <a href="${filePath}" download class="btn btn-primary ms-2"><i class="bi bi-download"></i> Tải về tệp gốc</a>
            </div>
        `;
    }
}
