/**
 * Theme Toggle Switcher cho Bootstrap 5.3
 * Lưu cài đặt vào LocalStorage
 */
document.addEventListener('DOMContentLoaded', () => {
    const themeKey = 'qlvb_theme_mode';
    const getStoredTheme = () => localStorage.getItem(themeKey);
    const setStoredTheme = theme => localStorage.setItem(themeKey, theme);

    const getPreferredTheme = () => {
        const storedTheme = getStoredTheme();
        if (storedTheme) return storedTheme;
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    };

    const setTheme = theme => {
        document.documentElement.setAttribute('data-bs-theme', theme);
        const iconBtn = document.getElementById('themeToggleBtn');
        if (iconBtn) {
            iconBtn.innerHTML = theme === 'dark' 
                ? '<i class="bi bi-sun-fill text-warning"></i> Sáng' 
                : '<i class="bi bi-moon-stars-fill text-primary"></i> Tối';
        }
    };

    // Áp dụng theme ban đầu
    setTheme(getPreferredTheme());

    // Toggle Button Click
    const toggleBtn = document.getElementById('themeToggleBtn');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-bs-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            setStoredTheme(newTheme);
            setTheme(newTheme);
        });
    }
});
