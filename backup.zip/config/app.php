<?php
/**
 * Cấu hình Ứng Dụng Hợp Nhất
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('APP_NAME', 'Hệ Thống Quản Lý Văn Bản Cá Nhân');
define('APP_VERSION', '1.0.0');
define('COPYRIGHT', 'Copyright © NAK26');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_EXTENSIONS', ['pdf', 'doc', 'docx']);

// Bật báo lỗi trong môi trường phát triển PHP 8.4
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
