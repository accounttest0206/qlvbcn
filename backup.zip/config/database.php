<?php
/**
 * Cấu hình Kết nối CSDL MySQL / MariaDB (PDO)
 * Dự án: Hệ Thống Quản Lý Văn Bản Cá Nhân
 */

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'mjhhuxsyhosting_qlvb');
define('DB_USER', 'mjhhuxsyhosting_admin');
define('DB_PASS', 'Admin@123');
define('DB_CHARSET', 'utf8mb4');

return [
    'host'     => DB_HOST,
    'port'     => DB_PORT,
    'dbname'   => DB_NAME,
    'user'     => DB_USER,
    'pass'     => DB_PASS,
    'charset'  => DB_CHARSET,
    'options'  => [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]
];
