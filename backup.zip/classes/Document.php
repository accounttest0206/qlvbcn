<?php
/**
 * Lớp Quản lý Văn bản (Document Model)
 */

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/ExtractiveSummarizer.php';

class Document {
    private Database $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * Lấy danh sách văn bản có Lọc & Tìm kiếm
     */
    public function getAll(int $userId, string $role, array $filters = []): array {
        $sql = "SELECT d.*, c.name AS category_name, u.fullname AS author_name 
                FROM documents d 
                LEFT JOIN categories c ON d.category_id = c.id 
                LEFT JOIN users u ON d.user_id = u.id 
                WHERE 1=1";
        $params = [];

        // Nếu là User thường, chỉ thấy văn bản do mình tạo hoặc được phân công
        if ($role !== 'Admin') {
            $sql .= " AND (d.user_id = :userId)";
            $params['userId'] = $userId;
        }

        // Tìm kiếm từ khóa (Tiêu đề, Số hiệu, Trích yếu)
        if (!empty($filters['keyword'])) {
            $sql .= " AND (d.title LIKE :kw1 OR d.doc_number LIKE :kw2 OR d.summary LIKE :kw3 OR d.auto_summary LIKE :kw4)";
            $kwVal = '%' . $filters['keyword'] . '%';
            $params['kw1'] = $kwVal;
            $params['kw2'] = $kwVal;
            $params['kw3'] = $kwVal;
            $params['kw4'] = $kwVal;
        }

        // Lọc theo Phân loại (Văn bản lưu / Văn bản thực hiện)
        if (!empty($filters['doc_type'])) {
            $sql .= " AND d.doc_type = :doc_type";
            $params['doc_type'] = $filters['doc_type'];
        }

        // Lọc theo Trạng thái thực hiện
        if (!empty($filters['status'])) {
            $sql .= " AND d.status = :status";
            $params['status'] = $filters['status'];
        }

        // Lọc theo Danh mục
        if (!empty($filters['category_id'])) {
            $sql .= " AND d.category_id = :catId";
            $params['catId'] = $filters['category_id'];
        }

        // Lọc theo Ngày ban hành
        if (!empty($filters['date_from'])) {
            $sql .= " AND d.issued_date >= :date_from";
            $params['date_from'] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $sql .= " AND d.issued_date <= :date_to";
            $params['date_to'] = $filters['date_to'];
        }

        $sql .= " ORDER BY d.updated_at DESC";

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Chi tiết văn bản theo ID
     */
    public function getById(int $id): array|false {
        $sql = "SELECT d.*, c.name AS category_name, u.fullname AS author_name, u.email AS author_email 
                FROM documents d 
                LEFT JOIN categories c ON d.category_id = c.id 
                LEFT JOIN users u ON d.user_id = u.id 
                WHERE d.id = :id LIMIT 1";
        return $this->db->fetchOne($sql, ['id' => $id]);
    }

    /**
     * Thêm văn bản mới & Tự động trích xuất Tóm tắt
     */
    public function create(array $data): int {
        // Tự động sinh tóm tắt Extractive TF-IDF
        $contentForSummary = $data['summary'] . " " . ($data['extracted_text'] ?? '');
        $autoSummary = ExtractiveSummarizer::summarize($contentForSummary, 3);

        $sql = "INSERT INTO documents 
                (user_id, category_id, title, doc_number, summary, auto_summary, doc_type, status, progress, file_path, file_type, file_size, issued_date, due_date) 
                VALUES 
                (:user_id, :category_id, :title, :doc_number, :summary, :auto_summary, :doc_type, :status, :progress, :file_path, :file_type, :file_size, :issued_date, :due_date)";

        $this->db->query($sql, [
            'user_id'     => $data['user_id'],
            'category_id' => $data['category_id'] ?: null,
            'title'       => $data['title'],
            'doc_number'  => $data['doc_number'],
            'summary'     => $data['summary'],
            'auto_summary'=> $autoSummary,
            'doc_type'    => $data['doc_type'],
            'status'      => $data['status'] ?? 'chua_xu_ly',
            'progress'    => $data['progress'] ?? 0,
            'file_path'   => $data['file_path'] ?? null,
            'file_type'   => $data['file_type'] ?? null,
            'file_size'   => $data['file_size'] ?? 0,
            'issued_date' => $data['issued_date'] ?: null,
            'due_date'    => $data['due_date'] ?: null
        ]);

        return (int)$this->db->lastInsertId();
    }

    /**
     * Cập nhật thông tin văn bản
     */
    public function update(int $id, array $data): bool {
        $contentForSummary = $data['summary'] . " " . ($data['extracted_text'] ?? '');
        $autoSummary = ExtractiveSummarizer::summarize($contentForSummary, 3);

        $sql = "UPDATE documents SET 
                category_id = :category_id,
                title = :title,
                doc_number = :doc_number,
                summary = :summary,
                auto_summary = :auto_summary,
                doc_type = :doc_type,
                issued_date = :issued_date,
                due_date = :due_date";

        $params = [
            'id'          => $id,
            'category_id' => $data['category_id'] ?: null,
            'title'       => $data['title'],
            'doc_number'  => $data['doc_number'],
            'summary'     => $data['summary'],
            'auto_summary'=> $autoSummary,
            'doc_type'    => $data['doc_type'],
            'issued_date' => $data['issued_date'] ?: null,
            'due_date'    => $data['due_date'] ?: null
        ];

        if (!empty($data['file_path'])) {
            $sql .= ", file_path = :file_path, file_type = :file_type, file_size = :file_size";
            $params['file_path'] = $data['file_path'];
            $params['file_type'] = $data['file_type'];
            $params['file_size'] = $data['file_size'];
        }

        $sql .= " WHERE id = :id";
        $this->db->query($sql, $params);
        return true;
    }

    /**
     * Cập nhật Tiến độ (% 0-100) và Trạng thái kèm Nhật ký
     */
    public function updateProgress(int $docId, int $userId, int $newProgress, string $newStatus, string $note = ''): bool {
        $doc = $this->getById($docId);
        if (!$doc) return false;

        $oldProgress = (int)$doc['progress'];
        $oldStatus = $doc['status'];

        // Tự động cập nhật status nếu progress = 100
        if ($newProgress >= 100) {
            $newProgress = 100;
            $newStatus = 'hoan_thanh';
        } elseif ($newProgress > 0 && $newStatus === 'chua_xu_ly') {
            $newStatus = 'dang_thuc_hien';
        }

        // 1. Update bảng documents
        $this->db->query(
            "UPDATE documents SET progress = :p, status = :s WHERE id = :id",
            ['p' => $newProgress, 's' => $newStatus, 'id' => $docId]
        );

        // 2. Insert nhật ký progress_logs
        $this->db->query(
            "INSERT INTO progress_logs (document_id, user_id, old_progress, new_progress, old_status, new_status, note) 
             VALUES (:doc_id, :user_id, :old_p, :new_p, :old_s, :new_s, :note)",
            [
                'doc_id'  => $docId,
                'user_id' => $userId,
                'old_p'   => $oldProgress,
                'new_p'   => $newProgress,
                'old_s'   => $oldStatus,
                'new_s'   => $newStatus,
                'note'    => $note
            ]
        );

        return true;
    }

    /**
     * Xóa văn bản
     */
    public function delete(int $id): bool {
        $doc = $this->getById($id);
        if ($doc && !empty($doc['file_path']) && file_exists(__DIR__ . '/../' . $doc['file_path'])) {
            @unlink(__DIR__ . '/../' . $doc['file_path']);
        }

        $this->db->query("DELETE FROM documents WHERE id = :id", ['id' => $id]);
        return true;
    }

    /**
     * Lấy Lịch sử Tiến độ
     */
    public function getProgressLogs(int $docId): array {
        $sql = "SELECT pl.*, u.fullname AS user_name 
                FROM progress_logs pl 
                JOIN users u ON pl.user_id = u.id 
                WHERE pl.document_id = :docId 
                ORDER BY pl.created_at DESC";
        return $this->db->fetchAll($sql, ['docId' => $docId]);
    }

    /**
     * Lấy Thống kê cho Dashboard
     */
    public function getDashboardStats(int $userId, string $role): array {
        $where = ($role !== 'Admin') ? " WHERE user_id = {$userId}" : "";

        $totalDocs = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM documents {$where}")['cnt'] ?? 0;
        $luuCount  = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM documents WHERE doc_type = 'luu' " . ($where ? "AND user_id = {$userId}" : ""))['cnt'] ?? 0;
        $thucHienCount = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM documents WHERE doc_type = 'thuc_hien' " . ($where ? "AND user_id = {$userId}" : ""))['cnt'] ?? 0;
        $hoanThanhCount = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM documents WHERE status = 'hoan_thanh' " . ($where ? "AND user_id = {$userId}" : ""))['cnt'] ?? 0;
        $dangThucHienCount = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM documents WHERE status = 'dang_thuc_hien' " . ($where ? "AND user_id = {$userId}" : ""))['cnt'] ?? 0;
        $chuaXuLyCount = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM documents WHERE status = 'chua_xu_ly' " . ($where ? "AND user_id = {$userId}" : ""))['cnt'] ?? 0;

        // 5 Văn bản mới cập nhật
        $recentDocs = $this->getAll($userId, $role, []);
        $recentDocs = array_slice($recentDocs, 0, 5);

        // Văn bản sắp/đến hạn chưa hoàn thành
        $upcomingSql = "SELECT d.*, c.name as category_name FROM documents d LEFT JOIN categories c ON d.category_id = c.id WHERE d.status != 'hoan_thanh' AND d.due_date IS NOT NULL " . ($where ? "AND d.user_id = {$userId}" : "") . " ORDER BY d.due_date ASC LIMIT 5";
        $upcomingDocs = $this->db->fetchAll($upcomingSql);

        // Phân bổ danh mục
        $catSql = "SELECT c.name, COUNT(d.id) as count FROM categories c LEFT JOIN documents d ON c.id = d.category_id " . ($where ? "AND d.user_id = {$userId}" : "") . " GROUP BY c.id, c.name";
        $catStats = $this->db->fetchAll($catSql);

        return [
            'total'           => (int)$totalDocs,
            'luu'             => (int)$luuCount,
            'thuc_hien'       => (int)$thucHienCount,
            'hoan_thanh'      => (int)$hoanThanhCount,
            'dang_thuc_hien'  => (int)$dangThucHienCount,
            'chua_xu_ly'      => (int)$chuaXuLyCount,
            'recent_docs'     => $recentDocs,
            'upcoming_docs'   => $upcomingDocs,
            'cat_stats'       => $catStats
        ];
    }
}
