<?php
/**
 * Lớp Tóm Tắt Văn Bản Extractive TF-IDF Thông Minh (Smart Extractive Summarizer)
 * Tự động trích xuất: Nội dung chính, Chỉ đạo trọng tâm & Các mốc thời gian / Hạn xử lý
 * Không phụ thuộc AI API bên ngoài
 */

class ExtractiveSummarizer {
    // Stop words Tiếng Việt mở rộng
    private static array $stopWords = [
        'và', 'của', 'là', 'có', 'cho', 'với', 'như', 'đã', 'đang', 'được', 'trong', 'để', 'vào', 'này',
        'khi', 'tại', 'theo', 'về', 'những', 'các', 'một', 'người', 'ra', 'sự', 'việc', 'đó', 'từ', 'trên',
        'cơ', 'quan', 'bộ', 'ban', 'ngành', 'ủy', 'phường', 'xã', 'thành', 'phố', 'tỉnh', 'số', 'rằng',
        'hoặc', 'vì', 'do', 'nên', 'cần', 'nhưng', 'mà', 'sau', 'trước', 'qua', 'bởi', 'cũng'
    ];

    // Từ khóa chỉ đạo / yêu cầu công việc
    private static array $actionKeywords = [
        'yêu cầu', 'chỉ đạo', 'giao', 'phụ trách', 'hoàn thành', 'chịu trách nhiệm', 
        'ban hành', 'quyết định', 'nghiệm thu', 'mục tiêu', 'nghiêm túc', 'thực hiện', 
        'triển khai', 'kiểm tra', 'rà soát', 'báo cáo', 'phối hợp', 'tiến hành', 'kế hoạch'
    ];

    /**
     * Tự động trích xuất tóm tắt đa chiều từ văn bản
     */
    public static function summarize(string $text, int $maxSentences = 3): string {
        $text = trim($text);
        if (mb_strlen($text) < 30) {
            return "Nội dung ngắn hoặc file dạng quét ảnh - Vui lòng tham khảo tài liệu gốc.";
        }

        // 1. Tách văn bản thành danh sách các câu sạch
        $rawSentences = preg_split('/(?<=[.!?;\n])\s+|\n+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        $sentences = [];
        foreach ($rawSentences as $s) {
            $cleaned = trim($s);
            if (mb_strlen($cleaned) >= 12) {
                $sentences[] = $cleaned;
            }
        }

        if (empty($sentences)) {
            return $text;
        }

        // 2. Trích xuất các mốc thời gian & hạn xử lý bằng Regular Expressions
        $timelines = self::extractTimelines($sentences);

        // 3. Tần suất từ (Term Frequency) & Trọng số TF-IDF
        $wordFreq = [];
        foreach ($sentences as $sentence) {
            $words = self::tokenize($sentence);
            foreach ($words as $word) {
                if (!in_array($word, self::$stopWords) && mb_strlen($word) > 1) {
                    $wordFreq[$word] = ($wordFreq[$word] ?? 0) + 1;
                }
            }
        }

        // 4. Tính điểm từng câu (TF-IDF + Trọng số vị trí + Trọng số từ khóa hành động)
        $scores = [];
        $actionSentences = [];

        foreach ($sentences as $index => $sentence) {
            $words = self::tokenize($sentence);
            $score = 0;
            $countedWords = 0;
            $lowerSentence = mb_strtolower($sentence, 'UTF-8');

            foreach ($words as $word) {
                if (isset($wordFreq[$word])) {
                    $score += $wordFreq[$word];
                    $countedWords++;
                }
            }

            if ($countedWords > 0) {
                $score = $score / sqrt($countedWords);
            }

            // Ưu tiên câu ở đầu văn bản (Tên/Mục đích chính)
            if ($index === 0) $score *= 1.4;
            else if ($index === 1) $score *= 1.2;

            // Ưu tiên câu chứa từ khóa chỉ đạo
            $hasAction = false;
            foreach (self::$actionKeywords as $kw) {
                if (mb_strpos($lowerSentence, $kw) !== false) {
                    $score *= 1.25;
                    $hasAction = true;
                }
            }

            if ($hasAction && mb_strlen($sentence) > 20) {
                $actionSentences[] = $sentence;
            }

            $scores[$index] = $score;
        }

        // 5. Chọn top câu có điểm cao nhất cho NỘI DUNG CHÍNH
        arsort($scores);
        $topIndices = array_slice(array_keys($scores), 0, min($maxSentences, count($sentences)));
        sort($topIndices);

        $mainContent = [];
        foreach ($topIndices as $idx) {
            $mainContent[] = $sentences[$idx];
        }

        // 6. Định dạng đầu ra thông minh và chuyên nghiệp
        $result = [];

        // Phần 1: Nội dung chính
        $result[] = "📌 NỘI DUNG CHÍNH:";
        foreach ($mainContent as $s) {
            $result[] = "• " . rtrim($s, '.') . ".";
        }

        // Phần 2: Chỉ đạo & Yêu cầu trọng tâm (nếu tìm thấy)
        if (!empty($actionSentences)) {
            $uniqueActions = array_unique(array_slice($actionSentences, 0, 2));
            $result[] = "\n⚡ CHỈ ĐẠO & YÊU CẦU QUAN TRỌNG:";
            foreach ($uniqueActions as $act) {
                $result[] = "• " . rtrim($act, '.') . ".";
            }
        }

        // Phần 3: Mốc thời gian & Hạn xử lý (nếu phát hiện)
        if (!empty($timelines)) {
            $result[] = "\n📅 MỐC THỜI GIAN & HẠN XỬ LÝ:";
            foreach (array_slice($timelines, 0, 3) as $timeItem) {
                $result[] = "• " . $timeItem;
            }
        }

        return implode("\n", $result);
    }

    /**
     * Tách & Phát hiện mốc thời gian trong danh sách câu
     */
    private static function extractTimelines(array $sentences): array {
        $found = [];

        // Pattern ngày tháng tiếng Việt
        $datePattern = '/(ngày\s+\d{1,2}\s+tháng\s+\d{1,2}(\s+năm\s+\d{4})?|từ\s+ngày\s+\d{1,2}[\/\-\.]\d{1,2}([\/\-\.]\d{4})?|trước\s+ngày\s+\d{1,2}[\/\-\.]\d{1,2}([\/\-\.]\d{4})?|đến\s+ngày\s+\d{1,2}[\/\-\.]\d{1,2}([\/\-\.]\d{4})?|\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{4}|tháng\s+\d{1,2}\/\d{4}|quý\s+[1-4]\/\d{4})/ui';

        foreach ($sentences as $sentence) {
            if (preg_match_all($datePattern, $sentence, $matches)) {
                $cleanedSent = trim(preg_replace('/\s+/', ' ', $sentence));
                if (!in_array($cleanedSent, $found)) {
                    $found[] = rtrim($cleanedSent, '.') . '.';
                }
            }
        }

        return $found;
    }

    /**
     * Tách từ tiếng Việt đơn giản
     */
    private static function tokenize(string $sentence): array {
        $clean = mb_strtolower($sentence, 'UTF-8');
        $clean = preg_replace('/[^\p{L}\p{N}\s]/u', ' ', $clean);
        return array_values(array_filter(explode(' ', $clean)));
    }
}
