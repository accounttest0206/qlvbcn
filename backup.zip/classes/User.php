<?php
/**
 * Lớp Quản Lý Người Dùng (User Management Model - OOP PDO)
 */

require_once __DIR__ . '/Database.php';

class User {
    private Database $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getAll(string $keyword = '', string $role = '', string $status = ''): array {
        $sql = "SELECT id, username, fullname, email, role, status, created_at FROM users WHERE 1=1";
        $params = [];

        if (!empty($keyword)) {
            $sql .= " AND (username LIKE :kw1 OR fullname LIKE :kw2 OR email LIKE :kw3)";
            $kwVal = "%$keyword%";
            $params['kw1'] = $kwVal;
            $params['kw2'] = $kwVal;
            $params['kw3'] = $kwVal;
        }

        if (!empty($role)) {
            $sql .= " AND role = :role";
            $params['role'] = $role;
        }

        if (!empty($status)) {
            $sql .= " AND status = :status";
            $params['status'] = $status;
        }

        $sql .= " ORDER BY id DESC";

        return $this->db->fetchAll($sql, $params);
    }

    public function getById(int $id): ?array {
        $sql = "SELECT id, username, fullname, email, role, status, created_at FROM users WHERE id = :id";
        return $this->db->fetchOne($sql, ['id' => $id]);
    }

    public function create(array $data): array {
        // Kiểm tra username trùng lặp
        $existing = $this->db->fetchOne("SELECT id FROM users WHERE username = :username", ['username' => $data['username']]);
        if ($existing) {
            return ['success' => false, 'message' => 'Tên tài khoản đã tồn tại!'];
        }

        $hashPassword = password_hash($data['password'] ?? '123456', PASSWORD_BCRYPT);

        $sql = "INSERT INTO users (username, password, fullname, email, role, status, created_at) 
                VALUES (:username, :password, :fullname, :email, :role, :status, NOW())";
        
        $this->db->query($sql, [
            'username' => $data['username'],
            'password' => $hashPassword,
            'fullname' => $data['fullname'],
            'email'    => $data['email'],
            'role'     => $data['role'] ?? 'User',
            'status'   => $data['status'] ?? 'active'
        ]);

        return ['success' => true, 'id' => $this->db->lastInsertId(), 'message' => 'Thêm người dùng mới thành công!'];
    }

    public function update(int $id, array $data): array {
        $fields = ["fullname = :fullname", "email = :email", "role = :role", "status = :status"];
        $params = [
            'fullname' => $data['fullname'],
            'email'    => $data['email'],
            'role'     => $data['role'],
            'status'   => $data['status'],
            'id'       => $id
        ];

        if (!empty($data['password'])) {
            $fields[] = "password = :password";
            $params['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        }

        $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = :id";
        $this->db->query($sql, $params);

        return ['success' => true, 'message' => 'Cập nhật thông tin người dùng thành công!'];
    }

    public function delete(int $id): array {
        if ($id === 1) {
            return ['success' => false, 'message' => 'Không thể xóa tài khoản Quản trị hệ thống gốc (Admin)!'];
        }

        $this->db->query("DELETE FROM users WHERE id = :id", ['id' => $id]);
        return ['success' => true, 'message' => 'Đã xóa người dùng thành công!'];
    }
}
