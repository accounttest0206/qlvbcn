<?php
/**
 * Lớp Xử lý Xác thực Người dùng & Phân quyền (Auth)
 */

require_once __DIR__ . '/Database.php';

class Auth {
    private Database $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function login(string $username, string $password): array {
        $sql = "SELECT * FROM users WHERE username = :username LIMIT 1";
        $user = $this->db->fetchOne($sql, ['username' => $username]);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];

            return ['success' => true, 'message' => 'Đăng nhập thành công!'];
        }

        return ['success' => false, 'message' => 'Tên đăng nhập hoặc mật khẩu không chính xác!'];
    }

    public static function check(): bool {
        return isset($_SESSION['user_id']);
    }

    public static function user(): ?array {
        if (!self::check()) return null;
        return [
            'id'       => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'fullname' => $_SESSION['fullname'],
            'email'    => $_SESSION['email'],
            'role'     => $_SESSION['role']
        ];
    }

    public static function isAdmin(): bool {
        return self::check() && $_SESSION['role'] === 'Admin';
    }

    public static function requireLogin(): void {
        if (!self::check()) {
            header('Location: login.php');
            exit;
        }
    }

    public function changePassword(int $userId, string $oldPassword, string $newPassword): array {
        $user = $this->db->fetchOne("SELECT password FROM users WHERE id = :id", ['id' => $userId]);
        if (!$user || !password_verify($oldPassword, $user['password'])) {
            return ['success' => false, 'message' => 'Mật khẩu cũ không chính xác!'];
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
        $this->db->query("UPDATE users SET password = :pass WHERE id = :id", [
            'pass' => $newHash,
            'id' => $userId
        ]);

        return ['success' => true, 'message' => 'Đổi mật khẩu thành công!'];
    }

    public static function logout(): void {
        unset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['fullname'], $_SESSION['email'], $_SESSION['role']);
        session_destroy();
        header('Location: login.php');
        exit;
    }
}
