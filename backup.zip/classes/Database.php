<?php
/**
 * Lớp Quản lý Kết nối Database PDO (Singleton & OOP)
 * Chống SQL Injection bằng Prepared Statements
 */

class Database {
    private static ?Database $instance = null;
    private ?PDO $pdo = null;

    private function __construct() {
        $config = require __DIR__ . '/../config/database.php';
        $dsn = sprintf("mysql:host=%s;port=%s;dbname=%s;charset=%s", 
            $config['host'], $config['port'], $config['dbname'], $config['charset']
        );

        try {
            $this->pdo = new PDO($dsn, $config['user'], $config['pass'], $config['options']);
        } catch (PDOException $e) {
            die("Lỗi kết nối CSDL: " . $e->getMessage());
        }
    }

    public static function getInstance(): Database {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection(): PDO {
        return $this->pdo;
    }

    // Phương thức Helper thực thi Query với Prepared Statement
    public function query(string $sql, array $params = []): PDOStatement {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function fetchAll(string $sql, array $params = []): array {
        return $this->query($sql, $params)->fetchAll();
    }

    public function fetchOne(string $sql, array $params = []): array|false {
        return $this->query($sql, $params)->fetch();
    }

    public function lastInsertId(): string {
        return $this->pdo->lastInsertId();
    }
}
