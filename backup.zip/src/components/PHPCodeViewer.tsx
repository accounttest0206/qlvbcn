import React, { useState, useEffect } from 'react';

interface PHPCodeViewerProps {
  show: boolean;
  onClose: () => void;
}

export const PHPCodeViewer: React.FC<PHPCodeViewerProps> = ({ show, onClose }) => {
  const [files, setFiles] = useState<Record<string, string>>({});
  const [selectedFile, setSelectedFile] = useState<string>('database.sql');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (show) {
      setLoading(true);
      fetch('/api/php-files')
        .then(res => res.json())
        .then(data => {
          setFiles(data);
          setLoading(false);
        })
        .catch(err => {
          console.error(err);
          setLoading(false);
        });
    }
  }, [show]);

  if (!show) return null;

  const copyToClipboard = () => {
    if (files[selectedFile]) {
      navigator.clipboard.writeText(files[selectedFile]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const downloadAllZip = () => {
    alert("Bạn có thể tải hoặc sao chép từng file mã nguồn PHP bên dưới trực tiếp!");
  };

  return (
    <div className="modal show d-block bg-black bg-opacity-50" tabIndex={-1}>
      <div className="modal-dialog modal-xl modal-dialog-scrollable">
        <div className="modal-content border-0 shadow-lg">
          <div className="modal-header bg-dark text-white">
            <h5 className="modal-header-title mb-0 d-flex align-items-center gap-2 fw-bold">
              <i className="bi bi-code-slash text-warning fs-4"></i>
              Mã Nguồn Full PHP 8.4 & SQL Dump
            </h5>
            <button type="button" className="btn-close btn-close-white" onClick={onClose}></button>
          </div>
          
          <div className="modal-body p-0">
            {loading ? (
              <div className="text-center py-5">
                <div className="spinner-border text-primary"></div>
                <p className="mt-2 text-muted">Đang tải cấu trúc mã nguồn PHP...</p>
              </div>
            ) : (
              <div className="row g-0">
                {/* File Sidebar */}
                <div className="col-12 col-md-4 border-end bg-body-tertiary p-3">
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <span className="fw-bold text-uppercase small text-muted">Danh Sách File Dự Án</span>
                    <span className="badge bg-primary">{Object.keys(files).length} files</span>
                  </div>
                  <div className="list-group list-group-flush rounded shadow-sm border">
                    {Object.keys(files).map(filePath => (
                      <button
                        key={filePath}
                        onClick={() => setSelectedFile(filePath)}
                        className={`list-group-item list-group-item-action border-0 d-flex align-items-center gap-2 ${
                          selectedFile === filePath ? 'active fw-bold' : ''
                        }`}
                        style={{ fontSize: '13px' }}
                      >
                        <i className={filePath.endsWith('.sql') ? 'bi bi-database-fill-gear text-warning' : 'bi bi-filetype-php text-primary'}></i>
                        <span className="text-truncate">{filePath}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Code Viewer Panel */}
                <div className="col-12 col-md-8 p-3 d-flex flex-column bg-dark text-light" style={{ minHeight: '500px' }}>
                  <div className="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom border-secondary">
                    <span className="fw-mono text-warning"><i className="bi bi-file-code me-2"></i>{selectedFile}</span>
                    <button onClick={copyToClipboard} className="btn btn-sm btn-outline-light">
                      {copied ? <><i className="bi bi-check2 me-1"></i>Đã Sao Chép!</> : <><i className="bi bi-clipboard me-1"></i>Sao Chép Mã</>}
                    </button>
                  </div>
                  <pre className="m-0 p-3 bg-black rounded text-light flex-grow-1 overflow-auto" style={{ fontFamily: 'monospace', fontSize: '12px', lineHeight: '1.5' }}>
                    <code>{files[selectedFile] || '// Đang tải nội dung file...'}</code>
                  </pre>
                </div>
              </div>
            )}
          </div>

          <div className="modal-footer bg-body border-top">
            <span className="text-muted small me-auto"><i className="bi bi-shield-check me-1 text-success"></i>Áp dụng chuẩn PHP 8.4 OOP, PDO, Prepared Statements, Bootstrap 5.3 & Copyright © NAK26</span>
            <button type="button" className="btn btn-secondary" onClick={onClose}>Đóng</button>
          </div>
        </div>
      </div>
    </div>
  );
};
