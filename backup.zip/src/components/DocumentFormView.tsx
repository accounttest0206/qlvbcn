import React, { useState, useEffect } from 'react';
import { Category, Document, User } from '../types';

interface DocumentFormViewProps {
  docId: number | null;
  categories: Category[];
  onCancel: () => void;
  onSuccess: (id: number) => void;
  currentUser: User;
}

export const DocumentFormView: React.FC<DocumentFormViewProps> = ({
  docId,
  categories,
  onCancel,
  onSuccess,
  currentUser
}) => {
  const isEdit = docId !== null;

  const [title, setTitle] = useState('');
  const [docNumber, setDocNumber] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [docType, setDocType] = useState('luu');
  const [status, setStatus] = useState('chua_xu_ly');
  const [summary, setSummary] = useState('');
  const [issuedDate, setIssuedDate] = useState(new Date().toISOString().substring(0, 10));
  const [dueDate, setDueDate] = useState('');
  const [fileObj, setFileObj] = useState<File | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isEdit && docId) {
      setLoading(true);
      fetch(`/api/documents/${docId}`)
        .then(res => res.json())
        .then(data => {
          const d: Document = data.document;
          setTitle(d.title);
          setDocNumber(d.doc_number);
          setCategoryId(d.category_id ? String(d.category_id) : '');
          setDocType(d.doc_type);
          setStatus(d.status);
          setSummary(d.summary);
          setIssuedDate(d.issued_date || '');
          setDueDate(d.due_date || '');
          setLoading(false);
        });
    }
  }, [docId, isEdit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !docNumber) {
      setError("Vui lòng nhập Tên văn bản và Số hiệu văn bản!");
      return;
    }

    setLoading(true);
    const payload = {
      title,
      doc_number: docNumber,
      category_id: categoryId ? Number(categoryId) : null,
      doc_type: docType,
      status,
      summary,
      issued_date: issuedDate || null,
      due_date: dueDate || null,
      user_id: currentUser.id,
      author_name: currentUser.fullname,
      file_path: fileObj ? `uploads/${fileObj.name}` : undefined,
      file_type: fileObj ? fileObj.name.split('.').pop() : undefined,
      file_size: fileObj ? fileObj.size : undefined
    };

    const url = isEdit ? `/api/documents/${docId}` : '/api/documents';
    const method = isEdit ? 'PUT' : 'POST';

    fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(res => res.json())
      .then(data => {
        setLoading(false);
        onSuccess(data.id || docId);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
        setError("Lỗi khi lưu dữ liệu văn bản!");
      });
  };

  if (loading && isEdit) {
    return (
      <div className="text-center py-5">
        <div className="spinner-border text-primary"></div>
        <p className="mt-2 text-muted">Đang tải dữ liệu văn bản...</p>
      </div>
    );
  }

  return (
    <div className="animate-fade-in row justify-content-center mb-5">
      <div className="col-12 col-lg-10">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h3 className="fw-bold mb-1">{isEdit ? 'Chỉnh Sửa Văn Bản' : 'Thêm Văn Bản Mới'}</h3>
            <p className="text-muted mb-0">Tự động trích xuất Tóm tắt Extractive TF-IDF khi lưu tài liệu</p>
          </div>
          <button onClick={onCancel} className="btn btn-outline-secondary">
            <i className="bi bi-arrow-left me-1"></i> Quay lại
          </button>
        </div>

        {error && (
          <div className="alert alert-danger alert-dismissible fade show mb-4">
            <i className="bi bi-exclamation-circle-fill me-2"></i>{error}
            <button type="button" className="btn-close" onClick={() => setError('')}></button>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="card border-0 shadow-sm mb-4">
            <div className="card-body p-4">
              <h5 className="fw-bold mb-3 border-bottom pb-2 text-primary"><i className="bi bi-info-circle me-2"></i>Thông Tin Cơ Bản</h5>
              <div className="row g-3">
                <div className="col-12 col-md-8">
                  <label className="form-label fw-semibold">Tên / Tiêu đề văn bản <span className="text-danger">*</span></label>
                  <input 
                    type="text" 
                    className="form-control" 
                    placeholder="Ví dụ: Quyết định v/v Kế hoạch..."
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>

                <div className="col-12 col-md-4">
                  <label className="form-label fw-semibold">Số hiệu văn bản <span className="text-danger">*</span></label>
                  <input 
                    type="text" 
                    className="form-control" 
                    placeholder="Ví dụ: 124/QĐ-UBND"
                    value={docNumber}
                    onChange={(e) => setDocNumber(e.target.value)}
                    required
                  />
                </div>

                <div className="col-12 col-md-4">
                  <label className="form-label fw-semibold">Phân loại văn bản</label>
                  <select className="form-select" value={docType} onChange={(e) => setDocType(e.target.value)}>
                    <option value="luu">Văn bản lưu (Tham khảo)</option>
                    <option value="thuc_hien">Văn bản thực hiện (Cần xử lý)</option>
                  </select>
                </div>

                <div className="col-12 col-md-4">
                  <label className="form-label fw-semibold">Danh mục</label>
                  <select className="form-select" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
                    <option value="">-- Chọn danh mục --</option>
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div className="col-12 col-md-4">
                  <label className="form-label fw-semibold">Trạng thái xử lý</label>
                  <select className="form-select" value={status} onChange={(e) => setStatus(e.target.value)}>
                    <option value="chua_xu_ly">Chưa xử lý</option>
                    <option value="dang_thuc_hien">Đang thực hiện</option>
                    <option value="hoan_thanh">Hoàn thành</option>
                  </select>
                </div>

                <div className="col-12 col-md-6">
                  <label className="form-label fw-semibold">Ngày ban hành</label>
                  <input type="date" className="form-control" value={issuedDate} onChange={(e) => setIssuedDate(e.target.value)} />
                </div>

                <div className="col-12 col-md-6">
                  <label className="form-label fw-semibold">Hạn xử lý (Nếu có)</label>
                  <input type="date" className="form-control" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
                </div>
              </div>
            </div>
          </div>

          <div className="card border-0 shadow-sm mb-4">
            <div className="card-body p-4">
              <h5 className="fw-bold mb-3 border-bottom pb-2 text-primary"><i className="bi bi-paperclip me-2"></i>Tệp Đính Kèm & Trích Yếu</h5>
              <div className="row g-3">
                <div className="col-12">
                  <label className="form-label fw-semibold">Tải lên tệp tài liệu (.pdf, .doc, .docx - Tối đa 10MB)</label>
                  <input 
                    type="file" 
                    className="form-control" 
                    accept=".pdf,.doc,.docx"
                    onChange={(e) => setFileObj(e.target.files ? e.target.files[0] : null)}
                  />
                  <small className="text-muted d-block mt-1"><i className="bi bi-magic me-1"></i>Hệ thống tự động chạy thuật toán lọc câu Extractive TF-IDF tạo tóm tắt 3-5 câu chính.</small>
                </div>

                <div className="col-12">
                  <label className="form-label fw-semibold">Trích yếu nội dung văn bản</label>
                  <textarea 
                    className="form-control" 
                    rows={4} 
                    placeholder="Nhập trích yếu hoặc tóm tắt nội dung chính..."
                    value={summary}
                    onChange={(e) => setSummary(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="d-flex justify-content-end gap-2 mb-5">
            <button type="button" onClick={onCancel} className="btn btn-secondary px-4">Hủy bỏ</button>
            <button type="submit" className="btn btn-primary px-4 fw-semibold" disabled={loading}>
              <i className="bi bi-save me-1"></i> {isEdit ? 'Cập Nhật' : 'Lưu Văn Bản'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
