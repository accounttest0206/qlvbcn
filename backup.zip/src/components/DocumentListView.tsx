import React, { useState, useEffect } from 'react';
import { Document, Category, User } from '../types';

interface DocumentListViewProps {
  categories: Category[];
  onSelectDoc: (id: number) => void;
  onEditDoc: (id: number) => void;
  onAddNew: () => void;
  currentUser: User;
}

export const DocumentListView: React.FC<DocumentListViewProps> = ({
  categories,
  onSelectDoc,
  onEditDoc,
  onAddNew,
  currentUser
}) => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [keyword, setKeyword] = useState('');
  const [docType, setDocType] = useState('');
  const [status, setStatus] = useState('');
  const [categoryId, setCategoryId] = useState('');

  const fetchDocs = () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (keyword) params.append('keyword', keyword);
    if (docType) params.append('doc_type', docType);
    if (status) params.append('status', status);
    if (categoryId) params.append('category_id', categoryId);
    params.append('user_role', currentUser.role);
    params.append('user_id', String(currentUser.id));

    fetch(`/api/documents?${params.toString()}`)
      .then(res => res.json())
      .then(data => {
        setDocuments(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchDocs();
  }, [keyword, docType, status, categoryId, currentUser]);

  const handleDelete = (id: number) => {
    if (confirm("Bạn có chắc chắn muốn xóa văn bản này không?")) {
      fetch(`/api/documents/${id}`, { method: 'DELETE' })
        .then(() => fetchDocs());
    }
  };

  return (
    <div className="animate-fade-in">
      {/* Title & Add */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h3 className="fw-bold mb-1">Quản Lý Văn Bản</h3>
          <p className="text-muted mb-0">Tìm kiếm, phân loại và cập nhật tiến độ các văn bản cá nhân</p>
        </div>
        <button onClick={onAddNew} className="btn btn-primary fw-semibold">
          <i className="bi bi-plus-circle me-1"></i> Thêm Văn Bản Mới
        </button>
      </div>

      {/* Filter Controls */}
      <div className="card border-0 shadow-sm mb-4">
        <div className="card-body">
          <div className="row g-3">
            <div className="col-12 col-md-4">
              <label className="form-label fw-semibold small">Từ khóa tìm kiếm</label>
              <div className="input-group">
                <span className="input-group-text"><i className="bi bi-search"></i></span>
                <input 
                  type="text" 
                  className="form-control" 
                  placeholder="Tiêu đề, số hiệu, trích yếu..."
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                />
              </div>
            </div>

            <div className="col-12 col-sm-6 col-md-2">
              <label className="form-label fw-semibold small">Phân loại</label>
              <select className="form-select" value={docType} onChange={(e) => setDocType(e.target.value)}>
                <option value="">-- Tất cả --</option>
                <option value="luu">Văn bản lưu</option>
                <option value="thuc_hien">Văn bản thực hiện</option>
              </select>
            </div>

            <div className="col-12 col-sm-6 col-md-3">
              <label className="form-label fw-semibold small">Trạng thái</label>
              <select className="form-select" value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="">-- Tất cả --</option>
                <option value="chua_xu_ly">Chưa xử lý</option>
                <option value="dang_thuc_hien">Đang thực hiện</option>
                <option value="hoan_thanh">Hoàn thành</option>
              </select>
            </div>

            <div className="col-12 col-sm-6 col-md-3">
              <label className="form-label fw-semibold small">Danh mục</label>
              <select className="form-select" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
                <option value="">-- Tất cả --</option>
                {categories.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Documents Table */}
      <div className="card border-0 shadow-sm">
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover align-middle mb-0">
              <thead className="table-light">
                <tr>
                  <th style={{ width: '50px' }}>STT</th>
                  <th>Số Hiệu & Tiêu Đề</th>
                  <th>Danh Mục</th>
                  <th>Phân Loại</th>
                  <th>Trạng Thái & Tiến Độ</th>
                  <th>Ngày Ban Hành</th>
                  <th className="text-center">Thao Tác</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={7} className="text-center py-5">
                      <div className="spinner-border text-primary" role="status"></div>
                      <p className="mt-2 text-muted mb-0">Đang tải danh sách văn bản...</p>
                    </td>
                  </tr>
                ) : documents.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-5 text-muted">
                      <i className="bi bi-inbox fs-1 d-block mb-2"></i>
                      Không tìm thấy văn bản phù hợp.
                    </td>
                  </tr>
                ) : (
                  documents.map((doc, idx) => (
                    <tr key={doc.id}>
                      <td className="text-center fw-bold text-muted">{idx + 1}</td>
                      <td>
                        <div className="fw-bold mb-1">
                          <button 
                            onClick={() => onSelectDoc(doc.id)} 
                            className="btn btn-link p-0 text-start text-decoration-none text-body fw-bold"
                          >
                            {doc.title}
                          </button>
                        </div>
                        <div className="small text-muted d-flex gap-2 align-items-center">
                          <span className="badge bg-light text-dark border"><i className="bi bi-hash"></i> {doc.doc_number}</span>
                          {doc.file_type && (
                            <span className="badge bg-secondary-subtle text-secondary border">
                              <i className="bi bi-file-earmark"></i> .{doc.file_type.toUpperCase()}
                            </span>
                          )}
                        </div>
                      </td>
                      <td>
                        <span className="badge bg-body-tertiary text-body border">
                          {doc.category_name || 'Chưa phân loại'}
                        </span>
                      </td>
                      <td>
                        {doc.doc_type === 'luu' ? (
                          <span className="badge bg-primary">Văn bản lưu</span>
                        ) : (
                          <span className="badge bg-warning text-dark">Thực hiện</span>
                        )}
                      </td>
                      <td>
                        {doc.status === 'hoan_thanh' ? (
                          <span className="badge bg-success"><i className="bi bi-check-lg"></i> Hoàn thành</span>
                        ) : doc.status === 'dang_thuc_hien' ? (
                          <div>
                            <span className="badge bg-info text-dark mb-1">Đang thực hiện</span>
                            <div className="progress" style={{ height: '6px', width: '100px' }}>
                              <div className="progress-bar bg-info" style={{ width: `${doc.progress}%` }}></div>
                            </div>
                            <small className="text-muted" style={{ fontSize: '11px' }}>{doc.progress}% tiến độ</small>
                          </div>
                        ) : (
                          <span className="badge bg-secondary">Chưa xử lý</span>
                        )}
                      </td>
                      <td className="small text-muted">
                        {doc.issued_date || 'N/A'}
                      </td>
                      <td className="text-center">
                        <div className="btn-group btn-group-sm">
                          <button onClick={() => onSelectDoc(doc.id)} className="btn btn-outline-primary" title="Xem chi tiết & Inline Preview">
                            <i className="bi bi-eye"></i>
                          </button>
                          <button onClick={() => onEditDoc(doc.id)} className="btn btn-outline-secondary" title="Sửa">
                            <i className="bi bi-pencil"></i>
                          </button>
                          <button onClick={() => handleDelete(doc.id)} className="btn btn-outline-danger" title="Xóa">
                            <i className="bi bi-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
