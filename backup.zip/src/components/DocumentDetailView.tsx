import React, { useState, useEffect } from 'react';
import { Document, ProgressLog, User } from '../types';

interface DocumentDetailViewProps {
  docId: number;
  onBack: () => void;
  onEdit: (id: number) => void;
  currentUser: User;
}

export const DocumentDetailView: React.FC<DocumentDetailViewProps> = ({
  docId,
  onBack,
  onEdit,
  currentUser
}) => {
  const [doc, setDoc] = useState<Document | null>(null);
  const [logs, setLogs] = useState<ProgressLog[]>([]);
  const [loading, setLoading] = useState(true);

  // Form State
  const [progressVal, setProgressVal] = useState<number>(0);
  const [statusVal, setStatusVal] = useState<string>('chua_xu_ly');
  const [noteVal, setNoteVal] = useState<string>('');
  const [docxHtml, setDocxHtml] = useState<string | null>(null);

  const fetchDetail = () => {
    setLoading(true);
    fetch(`/api/documents/${docId}`)
      .then(res => res.json())
      .then(data => {
        setDoc(data.document);
        setLogs(data.logs || []);
        setProgressVal(data.document.progress);
        setStatusVal(data.document.status);
        setLoading(false);

        // Simulated docx conversion via Mammoth in browser if .docx
        if (data.document.file_type === 'docx') {
          setDocxHtml(`
            <div class="p-3">
              <h5 class="fw-bold mb-3 border-bottom pb-2 text-primary"><i class="bi bi-file-word me-2"></i>Nội dung File Word (.docx) chuyển đổi trực tiếp:</h5>
              <p><strong>CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</strong><br><em>Độc lập - Tự do - Hạnh phúc</em></p>
              <h6 class="fw-bold mt-3">${data.document.title}</h6>
              <p class="text-muted">Số hiệu: ${data.document.doc_number} | Ngày lập: ${data.document.issued_date || '2026-08-01'}</p>
              <p class="lh-lg">${data.document.summary}</p>
              <div class="alert alert-light border mt-3">
                <strong>Chi tiết kế hoạch:</strong><br>
                1. Khảo sát hiện trạng và lập danh mục thiết bị.<br>
                2. Nâng cấp cấu hình máy chủ CSDL và hệ thống sao lưu dự phòng.<br>
                3. Đánh giá kiểm thử an ninh mạng và bàn giao nghiệm thu.
              </div>
            </div>
          `);
        }
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchDetail();
  }, [docId]);

  const handleUpdateProgress = (e: React.FormEvent, isComplete: boolean = false) => {
    e.preventDefault();
    const newP = isComplete ? 100 : progressVal;
    const newS = isComplete ? 'hoan_thanh' : statusVal;

    fetch(`/api/documents/${docId}/progress`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        new_progress: newP,
        new_status: newS,
        note: isComplete ? (noteVal || 'Đánh dấu hoàn thành công việc.') : noteVal,
        user_id: currentUser.id,
        user_name: currentUser.fullname
      })
    })
      .then(res => res.json())
      .then(() => {
        setNoteVal('');
        fetchDetail();
      });
  };

  if (loading || !doc) {
    return (
      <div className="text-center py-5">
        <div className="spinner-border text-primary"></div>
        <p className="mt-2 text-muted">Đang tải chi tiết văn bản...</p>
      </div>
    );
  }

  return (
    <div className="animate-fade-in mb-5">
      {/* Breadcrumb */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <button onClick={onBack} className="btn btn-outline-secondary btn-sm fw-semibold">
          <i className="bi bi-arrow-left me-1"></i> Quay lại danh sách
        </button>
        <button onClick={() => onEdit(doc.id)} className="btn btn-primary btn-sm fw-semibold">
          <i className="bi bi-pencil me-1"></i> Sửa Văn Bản
        </button>
      </div>

      {/* Header Card */}
      <div className="card border-0 shadow-sm mb-4">
        <div className="card-body p-4">
          <div className="d-flex justify-content-between align-items-start flex-wrap gap-3">
            <div>
              <div className="d-flex align-items-center gap-2 mb-2">
                <span className="badge bg-primary fs-6"><i className="bi bi-hash"></i> {doc.doc_number}</span>
                {doc.doc_type === 'luu' ? (
                  <span className="badge bg-info text-dark">Văn bản lưu</span>
                ) : (
                  <span className="badge bg-warning text-dark">Văn bản thực hiện</span>
                )}
                <span className="badge bg-body-tertiary text-body border">{doc.category_name || 'Chưa phân loại'}</span>
              </div>
              <h3 className="fw-bold mb-2">{doc.title}</h3>
              <div className="text-muted small d-flex flex-wrap gap-3">
                <span><i className="bi bi-person me-1"></i> Tác giả: <strong>{doc.author_name}</strong></span>
                <span><i className="bi bi-calendar3 me-1"></i> Ngày ban hành: <strong>{doc.issued_date || 'N/A'}</strong></span>
                {doc.due_date && (
                  <span className="text-danger"><i className="bi bi-clock-history me-1"></i> Hạn xử lý: <strong>{doc.due_date}</strong></span>
                )}
              </div>
            </div>

            <div className="d-flex gap-2">
              <a href="#" onClick={(e) => { e.preventDefault(); alert(`Tải xuống file gốc: ${doc.title}`); }} className="btn btn-outline-primary btn-sm">
                <i className="bi bi-download me-1"></i> Tải về (.{doc.file_type || 'doc'})
              </a>
            </div>
          </div>

          <hr className="my-3" />

          <div className="row align-items-center g-3">
            <div className="col-12 col-md-4">
              <div className="d-flex align-items-center gap-2">
                <span className="fw-semibold">Trạng thái:</span>
                {doc.status === 'hoan_thanh' ? (
                  <span className="badge bg-success fs-6"><i className="bi bi-check-circle-fill me-1"></i> Hoàn thành</span>
                ) : doc.status === 'dang_thuc_hien' ? (
                  <span className="badge bg-info text-dark fs-6"><i className="bi bi-hourglass-split me-1"></i> Đang thực hiện</span>
                ) : (
                  <span className="badge bg-secondary fs-6"><i className="bi bi-dash-circle me-1"></i> Chưa xử lý</span>
                )}
              </div>
            </div>

            <div className="col-12 col-md-8">
              <div className="d-flex align-items-center gap-3">
                <span className="fw-semibold text-nowrap">Tiến độ: {doc.progress}%</span>
                <div className="progress flex-grow-1" style={{ height: '10px' }}>
                  <div className={`progress-bar ${doc.progress === 100 ? 'bg-success' : 'bg-info'}`} style={{ width: `${doc.progress}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="row g-4">
        {/* Left: Summaries & Inline Document Viewer */}
        <div className="col-12 col-lg-8">
          {/* Automatic Extractive Summary Card (TF-IDF) */}
          <div className="card border-0 shadow-sm mb-4">
            <div className="card-header bg-primary bg-opacity-10 border-0 fw-bold d-flex align-items-center justify-content-between py-3">
              <span className="text-primary"><i className="bi bi-robot me-2 fs-5"></i>Tóm Tắt Tự Động (Thuật Toán Extractive TF-IDF)</span>
              <span className="badge bg-primary">Không dùng AI</span>
            </div>
            <div className="card-body">
              <p className="card-text text-body lh-base mb-0">
                {doc.auto_summary || "Chưa có tóm tắt tự động."}
              </p>
            </div>
          </div>

          {/* Original Summary */}
          <div className="card border-0 shadow-sm mb-4">
            <div className="card-header bg-transparent border-0 fw-bold pt-3">
              <i className="bi bi-text-paragraph text-secondary me-2"></i>Trích Yếu Văn Bản Gốc
            </div>
            <div className="card-body">
              <p className="text-body lh-base mb-0">
                {doc.summary || "Chưa nhập trích yếu."}
              </p>
            </div>
          </div>

          {/* Inline Document Previewer */}
          <div className="card border-0 shadow-sm mb-4">
            <div className="card-header bg-transparent border-0 fw-bold d-flex justify-content-between align-items-center pt-3">
              <span><i className="bi bi-file-earmark-word-fill text-primary me-2"></i>Xem File Trực Tiếp Trên Trình Duyệt</span>
              <span className="badge bg-secondary">.{doc.file_type ? doc.file_type.toUpperCase() : 'PDF'}</span>
            </div>
            <div className="card-body p-3">
              {doc.file_type === 'docx' && docxHtml ? (
                <div 
                  className="p-4 bg-body rounded border shadow-sm"
                  dangerouslySetInnerHTML={{ __html: docxHtml }}
                  style={{ maxHeight: '500px', overflowY: 'auto' }}
                ></div>
              ) : (
                <div className="bg-dark text-white rounded p-4 text-center" style={{ height: '450px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  <i className="bi bi-file-earmark-pdf fs-1 text-danger mb-3"></i>
                  <h5>Inline PDF Reader Embed</h5>
                  <p className="text-muted small max-w-md">Tệp PDF mẫu [<code>{doc.doc_number}.pdf</code>] đang hiển thị trực tiếp bằng bộ đọc PDF tích hợp trên trình duyệt.</p>
                  <button onClick={() => alert("Mở PDF bản đầy đủ trong cửa sổ mới")} className="btn btn-sm btn-outline-light mt-2">
                    <i className="bi bi-arrows-fullscreen me-1"></i>Phóng to toàn màn hình
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right: Progress Updates & Audit Trail */}
        <div className="col-12 col-lg-4">
          {/* Update Form Card */}
          <div className="card border-0 shadow-sm mb-4">
            <div className="card-header bg-transparent border-0 fw-bold pt-3">
              <i className="bi bi-sliders text-primary me-2"></i>Cập Nhật Tiến Độ Công Việc
            </div>
            <div className="card-body">
              <form onSubmit={(e) => handleUpdateProgress(e, false)}>
                <div className="mb-3">
                  <label className="form-label fw-semibold">Phần trăm tiến độ (%)</label>
                  <input 
                    type="range" 
                    className="form-range" 
                    min="0" 
                    max="100" 
                    step="5" 
                    value={progressVal}
                    onChange={(e) => setProgressVal(Number(e.target.value))}
                  />
                  <div className="text-end fw-bold text-primary">{progressVal}%</div>
                </div>

                <div className="mb-3">
                  <label className="form-label fw-semibold">Trạng thái xử lý</label>
                  <select 
                    className="form-select"
                    value={statusVal}
                    onChange={(e) => setStatusVal(e.target.value)}
                  >
                    <option value="chua_xu_ly">Chưa xử lý</option>
                    <option value="dang_thuc_hien">Đang thực hiện</option>
                    <option value="hoan_thanh">Hoàn thành</option>
                  </select>
                </div>

                <div className="mb-3">
                  <label className="form-label fw-semibold">Ghi chú tiến độ</label>
                  <textarea 
                    className="form-control" 
                    rows={2} 
                    placeholder="Nhập nội dung cập nhật..."
                    value={noteVal}
                    onChange={(e) => setNoteVal(e.target.value)}
                  />
                </div>

                <div className="d-grid gap-2">
                  <button type="submit" className="btn btn-primary fw-semibold">
                    <i className="bi bi-save me-1"></i> Cập Nhật Tiến Độ
                  </button>
                  <button 
                    type="button" 
                    onClick={(e) => handleUpdateProgress(e, true)} 
                    className="btn btn-success fw-semibold"
                  >
                    <i className="bi bi-check-all me-1"></i> Đánh Dấu Hoàn Thành
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Audit Logs Card */}
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-transparent border-0 fw-bold pt-3">
              <i className="bi bi-journal-text text-secondary me-2"></i>Nhật Ký Tiến Độ
            </div>
            <div className="card-body p-0">
              {logs.length === 0 ? (
                <div className="p-3 text-center text-muted small">Chưa có lịch sử cập nhật.</div>
              ) : (
                <div className="list-group list-group-flush" style={{ maxHeight: '350px', overflowY: 'auto' }}>
                  {logs.map((log) => (
                    <div key={log.id} className="list-group-item border-0 border-bottom p-3">
                      <div className="d-flex justify-content-between align-items-center mb-1">
                        <strong className="small">{log.user_name}</strong>
                        <span className="badge bg-body-tertiary text-muted" style={{ fontSize: '10px' }}>{log.created_at}</span>
                      </div>
                      <div className="small text-muted mb-1">
                        Thay đổi: <strong>{log.old_progress}%</strong> &rarr; <strong className="text-primary">{log.new_progress}%</strong>
                      </div>
                      {log.note && (
                        <div className="small text-body bg-body-tertiary p-2 rounded mt-1">
                          {log.note}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
