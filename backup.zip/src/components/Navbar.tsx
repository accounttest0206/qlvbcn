import React from 'react';
import { User } from '../types';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentUser: User;
  setCurrentUser: (u: User) => void;
  onOpenPHPViewer: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  currentUser,
  setCurrentUser,
  onOpenPHPViewer
}) => {
  const toggleRole = () => {
    if (currentUser.role === 'Admin') {
      setCurrentUser({
        id: 2,
        username: 'nguyenvana',
        fullname: 'Nguyễn Văn A',
        email: 'nguyenvana@qlvb.vn',
        role: 'User'
      });
    } else {
      setCurrentUser({
        id: 1,
        username: 'admin',
        fullname: 'Quản Trị Viên (Admin)',
        email: 'admin@qlvb.vn',
        role: 'Admin'
      });
    }
  };

  const toggleTheme = () => {
    const current = document.documentElement.getAttribute('data-bs-theme');
    const newTheme = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-bs-theme', newTheme);
    localStorage.setItem('qlvb_theme_mode', newTheme);
  };

  return (
    <nav className="navbar navbar-expand-lg bg-body border-bottom sticky-top shadow-sm">
      <div className="container-fluid px-lg-4">
        <a 
          className="navbar-brand d-flex align-items-center gap-2 fw-bold text-primary" 
          href="#" 
          onClick={(e) => { e.preventDefault(); setCurrentTab('dashboard'); }}
        >
          <span className="bg-primary text-white rounded-3 p-2 d-inline-flex align-items-center justify-content-center" style={{ width: '38px', height: '38px' }}>
            <i className="bi bi-folder-symlink-fill fs-5"></i>
          </span>
          <span className="d-none d-sm-inline">Hệ Thống Quản Lý Văn Bản Cá Nhân</span>
          <span className="d-inline d-sm-none">QLVB</span>
        </a>

        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarMain">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
            <li className="nav-item">
              <button 
                className={`nav-link border-0 bg-transparent text-start ${currentTab === 'dashboard' ? 'active fw-bold text-primary' : ''}`}
                onClick={() => setCurrentTab('dashboard')}
              >
                <i className="bi bi-speedometer2 me-1"></i> Dashboard
              </button>
            </li>
            <li className="nav-item">
              <button 
                className={`nav-link border-0 bg-transparent text-start ${currentTab === 'documents' ? 'active fw-bold text-primary' : ''}`}
                onClick={() => setCurrentTab('documents')}
              >
                <i className="bi bi-file-earmark-text me-1"></i> Quản Lý Văn Bản
              </button>
            </li>
            <li className="nav-item">
              <button 
                className={`nav-link border-0 bg-transparent text-start ${currentTab === 'add_document' ? 'active fw-bold text-primary' : ''}`}
                onClick={() => setCurrentTab('add_document')}
              >
                <i className="bi bi-plus-circle me-1"></i> Thêm Văn Bản Mới
              </button>
            </li>
          </ul>

          <div className="d-flex align-items-center gap-2 flex-wrap">
            {/* Mã nguồn PHP Inspector Button */}
            <button onClick={onOpenPHPViewer} className="btn btn-sm btn-outline-warning text-dark-emphasis fw-semibold">
              <i className="bi bi-code-slash me-1"></i>Xem Mã Nguồn PHP & SQL
            </button>

            {/* Theme Toggle */}
            <button onClick={toggleTheme} className="btn btn-sm btn-outline-secondary" title="Chuyển chế độ Sáng/Tối">
              <i className="bi bi-moon-stars-fill text-primary me-1"></i> Theme
            </button>

            {/* Role Switcher for Demo */}
            <button onClick={toggleRole} className="btn btn-sm btn-outline-info" title="Chuyển đổi quyền Admin / User để test">
              <i className="bi bi-person-badge me-1"></i>{currentUser.role}
            </button>

            {/* User Info */}
            <div className="dropdown">
              <button className="btn btn-outline-primary btn-sm dropdown-toggle d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown">
                <i className="bi bi-person-circle"></i>
                <span className="fw-semibold d-none d-md-inline">{currentUser.fullname}</span>
              </button>
              <ul className="dropdown-menu dropdown-menu-end shadow border-0">
                <li><span className="dropdown-item-text text-muted small"><i className="bi bi-envelope me-1"></i>{currentUser.email}</span></li>
                <li><span className="dropdown-item-text text-muted small"><i className="bi bi-shield-lock me-1"></i>Quyền: {currentUser.role}</span></li>
                <li><hr className="dropdown-divider" /></li>
                <li><a className="dropdown-item text-danger" href="#" onClick={(e) => { e.preventDefault(); alert("Đã đăng xuất phiên dùng thử."); }}><i className="bi bi-box-arrow-right me-2"></i>Đăng xuất</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};
