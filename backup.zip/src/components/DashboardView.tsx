import React, { useEffect, useRef } from 'react';
import { DashboardStats, Document, User } from '../types';

interface DashboardViewProps {
  stats: DashboardStats | null;
  onSelectDoc: (id: number) => void;
  onAddNew: () => void;
  onViewAll: () => void;
  currentUser: User;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  stats,
  onSelectDoc,
  onAddNew,
  onViewAll,
  currentUser
}) => {
  const statusChartRef = useRef<HTMLCanvasElement | null>(null);
  const catChartRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!stats) return;

    let statusChartInstance: any = null;
    let catChartInstance: any = null;

    // Load Chart.js dynamically or use window.Chart
    const Chart = (window as any).Chart;

    if (Chart && statusChartRef.current) {
      statusChartInstance = new Chart(statusChartRef.current, {
        type: 'doughnut',
        data: {
          labels: ['Chưa xử lý', 'Đang thực hiện', 'Hoàn thành'],
          datasets: [{
            data: [stats.chua_xu_ly, stats.dang_thuc_hien, stats.hoan_thanh],
            backgroundColor: ['#6c757d', '#0dcaf0', '#198754']
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { position: 'bottom' } }
        }
      });
    }

    if (Chart && catChartRef.current) {
      const catLabels = stats.cat_stats.map(c => c.name);
      const catData = stats.cat_stats.map(c => c.count);

      catChartInstance = new Chart(catChartRef.current, {
        type: 'bar',
        data: {
          labels: catLabels,
          datasets: [{
            label: 'Số lượng văn bản',
            data: catData,
            backgroundColor: '#0d6efd',
            borderRadius: 6
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
        }
      });
    }

    return () => {
      if (statusChartInstance) statusChartInstance.destroy();
      if (catChartInstance) catChartInstance.destroy();
    };
  }, [stats]);

  if (!stats) {
    return (
      <div className="text-center py-5">
        <div className="spinner-border text-primary" role="status"></div>
        <p className="mt-2 text-muted">Đang tải dữ liệu tổng quan...</p>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      {/* Title Banner */}
      <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h3 className="fw-bold mb-1">Tổng Quan Hệ Thống</h3>
          <p className="text-muted mb-0">Xin chào, <strong>{currentUser.fullname}</strong>! Dưới đây là thống kê quản lý văn bản cá nhân.</p>
        </div>
        <div className="d-flex gap-2">
          <button onClick={onAddNew} className="btn btn-primary fw-semibold">
            <i className="bi bi-file-earmark-plus me-1"></i> Thêm Văn Bản Mới
          </button>
          <button onClick={onViewAll} className="btn btn-outline-secondary fw-semibold">
            <i className="bi bi-list-task me-1"></i> Tất Cả Văn Bản
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="row g-3 mb-4">
        <div className="col-12 col-sm-6 col-xl-3">
          <div className="card border-0 shadow-sm h-100 bg-body">
            <div className="card-body d-flex align-items-center">
              <div className="bg-primary bg-opacity-10 text-primary rounded-3 p-3 me-3">
                <i className="bi bi-files fs-2"></i>
              </div>
              <div>
                <h6 className="text-muted fw-normal mb-1">Tổng Số Văn Bản</h6>
                <h3 className="fw-bold mb-0">{stats.total}</h3>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-sm-6 col-xl-3">
          <div className="card border-0 shadow-sm h-100 bg-body">
            <div className="card-body d-flex align-items-center">
              <div className="bg-info bg-opacity-10 text-info rounded-3 p-3 me-3">
                <i className="bi bi-archive-fill fs-2"></i>
              </div>
              <div>
                <h6 className="text-muted fw-normal mb-1">Văn Bản Lưu (Tham Khảo)</h6>
                <h3 className="fw-bold mb-0 text-info">{stats.luu}</h3>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-sm-6 col-xl-3">
          <div className="card border-0 shadow-sm h-100 bg-body">
            <div className="card-body d-flex align-items-center">
              <div className="bg-warning bg-opacity-10 text-warning rounded-3 p-3 me-3">
                <i className="bi bi-hourglass-split fs-2"></i>
              </div>
              <div>
                <h6 className="text-muted fw-normal mb-1">Đang Thực Hiện / Xử Lý</h6>
                <h3 className="fw-bold mb-0 text-warning">{stats.dang_thuc_hien + stats.chua_xu_ly}</h3>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-sm-6 col-xl-3">
          <div className="card border-0 shadow-sm h-100 bg-body">
            <div className="card-body d-flex align-items-center">
              <div className="bg-success bg-opacity-10 text-success rounded-3 p-3 me-3">
                <i className="bi bi-check-circle-fill fs-2"></i>
              </div>
              <div>
                <h6 className="text-muted fw-normal mb-1">Đã Hoàn Thành</h6>
                <h3 className="fw-bold mb-0 text-success">{stats.hoan_thanh}</h3>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="row g-3 mb-4">
        <div className="col-12 col-lg-5">
          <div className="card border-0 shadow-sm h-100">
            <div className="card-header bg-transparent border-0 pt-3 fw-bold">
              <i className="bi bi-pie-chart-fill text-primary me-2"></i>Trạng Thái Văn Bản
            </div>
            <div className="card-body d-flex align-items-center justify-content-center">
              <div style={{ width: '100%', maxWidth: '280px', height: '230px' }}>
                <canvas ref={statusChartRef}></canvas>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-lg-7">
          <div className="card border-0 shadow-sm h-100">
            <div className="card-header bg-transparent border-0 pt-3 fw-bold">
              <i className="bi bi-bar-chart-line-fill text-success me-2"></i>Phân Loại Theo Danh Mục
            </div>
            <div className="card-body">
              <div style={{ width: '100%', height: '230px' }}>
                <canvas ref={catChartRef}></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent & Upcoming Tables */}
      <div className="row g-3 mb-4">
        {/* Recent Docs */}
        <div className="col-12 col-xl-7">
          <div className="card border-0 shadow-sm h-100">
            <div className="card-header bg-transparent border-0 pt-3 fw-bold d-flex justify-content-between align-items-center">
              <span><i className="bi bi-clock-history text-primary me-2"></i>Văn Bản Mới Cập Nhật</span>
              <button onClick={onViewAll} className="btn btn-sm btn-link text-decoration-none">Xem tất cả &raquo;</button>
            </div>
            <div className="card-body p-0">
              <div className="table-responsive">
                <table className="table table-hover align-middle mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>Số Hiệu & Tiêu Đề</th>
                      <th>Loại</th>
                      <th>Trạng Thái / Tiến Độ</th>
                      <th className="text-center">Thao Tác</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stats.recent_docs.map((doc) => (
                      <tr key={doc.id}>
                        <td>
                          <div className="fw-bold text-truncate" style={{ maxWidth: '260px' }}>
                            <button 
                              onClick={() => onSelectDoc(doc.id)} 
                              className="btn btn-link p-0 text-start text-decoration-none text-body fw-bold"
                            >
                              {doc.title}
                            </button>
                          </div>
                          <small className="text-muted"><i className="bi bi-hash"></i> {doc.doc_number}</small>
                        </td>
                        <td>
                          {doc.doc_type === 'luu' ? (
                            <span className="badge bg-primary">Văn bản lưu</span>
                          ) : (
                            <span className="badge bg-warning text-dark">Thực hiện</span>
                          )}
                        </td>
                        <td>
                          {doc.status === 'hoan_thanh' ? (
                            <span className="badge bg-success">Hoàn thành</span>
                          ) : doc.status === 'dang_thuc_hien' ? (
                            <div>
                              <span className="badge bg-info text-dark mb-1">Đang xử lý ({doc.progress}%)</span>
                              <div className="progress" style={{ height: '5px', width: '80px' }}>
                                <div className="progress-bar bg-info" style={{ width: `${doc.progress}%` }}></div>
                              </div>
                            </div>
                          ) : (
                            <span className="badge bg-secondary">Chưa xử lý</span>
                          )}
                        </td>
                        <td className="text-center">
                          <button onClick={() => onSelectDoc(doc.id)} className="btn btn-sm btn-outline-primary" title="Xem chi tiết">
                            <i className="bi bi-eye"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Upcoming Due Docs */}
        <div className="col-12 col-xl-5">
          <div className="card border-0 shadow-sm h-100">
            <div className="card-header bg-transparent border-0 pt-3 fw-bold text-danger">
              <i className="bi bi-calendar-event-fill me-2"></i>Cần Xử Lý / Sắp Đến Hạn
            </div>
            <div className="card-body p-3">
              {stats.upcoming_docs.length === 0 ? (
                <div className="text-center py-4 text-muted">
                  <i className="bi bi-check-circle text-success fs-2 d-block mb-2"></i>
                  Không có văn bản nào sắp đến hạn cần xử lý!
                </div>
              ) : (
                <div className="list-group list-group-flush">
                  {stats.upcoming_docs.map((uDoc) => (
                    <button
                      key={uDoc.id}
                      onClick={() => onSelectDoc(uDoc.id)}
                      className="list-group-item list-group-item-action border-0 mb-2 rounded bg-body-tertiary text-start"
                    >
                      <div className="d-flex w-100 justify-content-between align-items-center mb-1">
                        <span className="fw-bold text-truncate" style={{ maxWidth: '200px' }}>{uDoc.title}</span>
                        <span className="badge bg-danger">Hạn: {uDoc.due_date}</span>
                      </div>
                      <div className="d-flex justify-content-between align-items-center small text-muted">
                        <span><i className="bi bi-hash"></i> {uDoc.doc_number}</span>
                        <span className="text-warning fw-semibold">Tiến độ: {uDoc.progress}%</span>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
