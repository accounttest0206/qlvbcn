import React, { useState, useEffect } from 'react';
import { User, Category, DashboardStats } from './types';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { DocumentListView } from './components/DocumentListView';
import { DocumentDetailView } from './components/DocumentDetailView';
import { DocumentFormView } from './components/DocumentFormView';
import { PHPCodeViewer } from './components/PHPCodeViewer';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User>({
    id: 1,
    username: 'admin',
    fullname: 'Quản Trị Viên (Admin)',
    email: 'admin@qlvb.vn',
    role: 'Admin'
  });

  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [selectedDocId, setSelectedDocId] = useState<number | null>(null);
  const [editDocId, setEditDocId] = useState<number | null>(null);

  const [categories, setCategories] = useState<Category[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [showPHPViewer, setShowPHPViewer] = useState<boolean>(false);

  // Load Categories & Dashboard Stats
  const loadStats = () => {
    fetch('/api/stats')
      .then(res => res.json())
      .then(data => setStats(data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetch('/api/categories')
      .then(res => res.json())
      .then(data => setCategories(data))
      .catch(err => console.error(err));

    loadStats();
  }, [currentUser]);

  const handleSelectDoc = (id: number) => {
    setSelectedDocId(id);
    setCurrentTab('document_detail');
  };

  const handleEditDoc = (id: number) => {
    setEditDocId(id);
    setCurrentTab('edit_document');
  };

  const handleAddNew = () => {
    setEditDocId(null);
    setCurrentTab('add_document');
  };

  return (
    <div className="min-vh-100 d-flex flex-column bg-body-tertiary">
      <Navbar 
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currentUser={currentUser}
        setCurrentUser={setCurrentUser}
        onOpenPHPViewer={() => setShowPHPViewer(true)}
      />

      <main className="container-fluid px-lg-4 py-4 flex-grow-1">
        {currentTab === 'dashboard' && (
          <DashboardView 
            stats={stats}
            onSelectDoc={handleSelectDoc}
            onAddNew={handleAddNew}
            onViewAll={() => setCurrentTab('documents')}
            currentUser={currentUser}
          />
        )}

        {currentTab === 'documents' && (
          <DocumentListView 
            categories={categories}
            onSelectDoc={handleSelectDoc}
            onEditDoc={handleEditDoc}
            onAddNew={handleAddNew}
            currentUser={currentUser}
          />
        )}

        {currentTab === 'document_detail' && selectedDocId && (
          <DocumentDetailView 
            docId={selectedDocId}
            onBack={() => { setCurrentTab('documents'); loadStats(); }}
            onEdit={handleEditDoc}
            currentUser={currentUser}
          />
        )}

        {(currentTab === 'add_document' || currentTab === 'edit_document') && (
          <DocumentFormView 
            docId={currentTab === 'edit_document' ? editDocId : null}
            categories={categories}
            onCancel={() => setCurrentTab('documents')}
            onSuccess={(id) => {
              setSelectedDocId(id);
              setCurrentTab('document_detail');
              loadStats();
            }}
            currentUser={currentUser}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-body py-3 border-top text-center text-muted small mt-auto">
        <div className="container-fluid px-lg-4 d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
          <div>
            <strong>Hệ Thống Quản Lý Văn Bản Cá Nhân</strong> - Phiên bản 1.0 (PHP 8.4 OOP PDO)
          </div>
          <div>
            <span className="fw-bold text-primary">Copyright © NAK26</span>
          </div>
        </div>
      </footer>

      {/* PHP Code & SQL Dump Modal Inspector */}
      <PHPCodeViewer show={showPHPViewer} onClose={() => setShowPHPViewer(false)} />
    </div>
  );
}
