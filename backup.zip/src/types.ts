export interface User {
  id: number;
  username: string;
  fullname: string;
  email: string;
  role: 'Admin' | 'User';
}

export interface Category {
  id: number;
  name: string;
  description: string;
}

export interface Document {
  id: number;
  user_id: number;
  category_id: number | null;
  category_name?: string;
  title: string;
  doc_number: string;
  summary: string;
  auto_summary: string;
  doc_type: 'luu' | 'thuc_hien';
  status: 'chua_xu_ly' | 'dang_thuc_hien' | 'hoan_thanh';
  progress: number;
  file_path: string | null;
  file_type: string | null;
  file_size: number;
  issued_date: string | null;
  due_date: string | null;
  created_at: string;
  author_name: string;
}

export interface ProgressLog {
  id: number;
  document_id: number;
  user_id: number;
  user_name: string;
  old_progress: number;
  new_progress: number;
  old_status: string;
  new_status: string;
  note: string;
  created_at: string;
}

export interface DashboardStats {
  total: number;
  luu: number;
  thuc_hien: number;
  hoan_thanh: number;
  dang_thuc_hien: number;
  chua_xu_ly: number;
  recent_docs: Document[];
  upcoming_docs: Document[];
  cat_stats: { name: string; count: number }[];
}
