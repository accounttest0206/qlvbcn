<?php
if (!defined('APP_NAME')) {
    die('Restricted access');
}
?>
    </main>

    <!-- Footer -->
    <footer class="bg-body py-3 text-center text-muted small mt-auto">
        <div class="container-fluid px-lg-4 d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
            <div>
                <strong><?= APP_NAME ?></strong> - Phiên bản 1.0 (PHP 8.4 OOP PDO)
            </div>
            <div>
                <span class="fw-bold text-primary"><?= COPYRIGHT ?></span>
            </div>
        </div>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
