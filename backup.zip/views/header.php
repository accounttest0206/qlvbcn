<?php
if (!defined('APP_NAME')) {
    die('Restricted access');
}
$currentUser = Auth::user();
?>
<!DOCTYPE html>
<html lang="vi" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' - ' : '' ?><?= APP_NAME ?></title>
    
    <!-- Bootstrap 5.3 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <!-- Custom Theme & Viewer JS -->
    <script src="assets/js/theme.js" defer></script>
    <script src="assets/js/viewer.js" defer></script>
    
    <!-- Mammoth.js cho DOCX Preview -->
    <script src="https://cdn.jsdelivr.net/npm/mammoth@1.8.0/mammoth.browser.min.js"></script>
    
    <!-- Chart.js cho Dashboard -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        .navbar-brand-icon { width: 38px; height: 38px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; }
        .doc-badge-luu { background-color: #0d6efd; color: #fff; }
        .doc-badge-thuc-hien { background-color: #fd7e14; color: #fff; }
        .status-chua-xu-ly { background-color: #6c757d; }
        .status-dang-thuc-hien { background-color: #0dcaf0; color: #000; }
        .status-hoan-thanh { background-color: #198754; }
        footer { margin-top: auto; border-top: 1px solid var(--bs-border-color); }
        .page-wrapper { min-height: 100vh; display: flex; flex-direction: column; }
    </style>
</head>
<body class="bg-body-tertiary">
<div class="page-wrapper">
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg bg-body border-bottom sticky-top shadow-sm">
        <div class="container-fluid px-lg-4">
            <a class="navbar-brand d-flex align-items-center gap-2 fw-bold" href="index.php">
                <span class="navbar-brand-icon bg-primary text-white">
                    <i class="bi bi-folder-symlink-fill fs-5"></i>
                </span>
                <span class="d-none d-sm-inline"><?= APP_NAME ?></span>
                <span class="d-inline d-sm-none">QLVB</span>
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active fw-bold' : '' ?>" href="index.php">
                            <i class="bi bi-speedometer2 me-1"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'documents.php') ? 'active fw-bold' : '' ?>" href="documents.php">
                            <i class="bi bi-file-earmark-text me-1"></i> Quản Lý Văn Bản
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'document_add.php') ? 'active fw-bold' : '' ?>" href="document_add.php">
                            <i class="bi bi-plus-circle me-1"></i> Thêm Văn Bản
                        </a>
                    </li>
                </ul>

                <div class="d-flex align-items-center gap-3">
                    <!-- Switch Theme -->
                    <button id="themeToggleBtn" class="btn btn-sm btn-outline-secondary d-flex align-items-center gap-1">
                        <i class="bi bi-moon-stars-fill text-primary"></i> Tối
                    </button>

                    <!-- User Profile Dropdown -->
                    <div class="dropdown">
                        <button class="btn btn-outline-primary btn-sm dropdown-toggle d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle fs-6"></i>
                            <span class="fw-semibold"><?= htmlspecialchars($currentUser['fullname'] ?? '') ?></span>
                            <span class="badge bg-secondary"><?= htmlspecialchars($currentUser['role'] ?? 'User') ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                            <li><span class="dropdown-item-text text-muted small"><i class="bi bi-envelope me-1"></i> <?= htmlspecialchars($currentUser['email'] ?? '') ?></span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>Đăng xuất</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content Container -->
    <main class="container-fluid px-lg-4 py-4">
